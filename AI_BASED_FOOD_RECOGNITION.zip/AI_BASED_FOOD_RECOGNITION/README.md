# AI-Based Food Recognition and Nutrition Analysis System

An end-to-end Computer Vision and Deep Learning system designed to automatically recognize food items from images (or camera captures) and estimate their comprehensive nutritional values (calories, protein, carbohydrates, fat, dietary fiber, sodium, vitamins, and Nutri-Scores).

Based on the **Food-101 Benchmark Dataset** and **EfficientNet Transfer Learning**.

---

## 👥 Project Members
- **T. Kedhar** — URN: `24011CSEAI0050`
- **S. Sindhu** — URN: `24011CSEAI0047`
- **M. ManiDeepika** — URN: `24011CSEAI0138`

---

## 🚀 Key Features

1. **AI Image Acquisition & Preprocessing**:
   - Drag-and-drop or file browser upload (JPG, PNG, WEBP).
   - Real-time webcam snapshot capture directly in browser.
   - Standard 224×224 RGB image normalization with ImageNet/Food-101 statistics ($\mu=[0.485, 0.456, 0.406]$, $\sigma=[0.229, 0.224, 0.225]$).
   - 1-Click benchmark preset showcase (Biryani/Curry, Pizza, Caesar Salad, Sushi).

2. **Deep Learning Classification Engine**:
   - **EfficientNet-B0 with Transfer Learning**: Compound scaling for high accuracy with low computational overhead.
   - **MobileNet-V2 & Custom FoodCNN**: Alternative architectures for ablation comparisons.
   - **Softmax Confidence Scoring**: Ranked Top-5 predictions with percentage likelihoods.
   - **CNN Feature Attention / Saliency Map**: Visual heatmap showing image regions analyzed by the neural network.

3. **Automated Nutrition Analysis & RDA % Profiling**:
   - 1-to-1 mapping with the **Food-101 Nutritional Information Dataset** (covering all 101 official classes).
   - Macronutrients: Calories (kcal), Protein (g), Carbohydrates (g), Total Fats (g).
   - Micronutrients: Dietary Fiber (g), Sodium (mg), Sugars (g), Potassium (mg).
   - Daily Recommended Allowance (RDA) % based on WHO/FDA 2,000 kcal standard reference diet.
   - Dynamic portion weight slider (25g to 500g) with real-time recalculation.
   - Algorithmic **Nutri-Score Rating** (Grade A to E).
   - Physical activity burn-off equivalents (Walking, Jogging, Cycling, Swimming).
   - Smart dietary insights (Protein adequacy, Sodium warnings, Glycemic impact).

4. **Dietary Dashboard & History Tracking**:
   - Persistent SQLite database (`data/food_history.db`).
   - Daily calorie budget meter & remaining calorie tracker.
   - Macronutrient distribution doughnut chart (Protein vs Carbs vs Fat).
   - 7-day caloric intake trend bar chart.
   - Logged meals table with thumbnails, confidence scores, timestamps, and delete controls.
   - 1-Click JSON export of meal history.

5. **Food-101 Database Explorer**:
   - Searchable catalog of all 101 official Food-101 categories with nutrition facts.

6. **Dual User Interface Options**:
   - **Modern Glassmorphic Web App**: FastAPI + Vanilla HTML5/CSS3/JavaScript + Chart.js.
   - **Academic Streamlit App**: For lab viva, project presentations, and thesis demos.

---

## 📁 Project Architecture

```
AI_BASED_FOOD_RECOGNITION/
├── data/
│   ├── food101_nutrition.json      # Complete nutritional profiles for all 101 classes
│   ├── food101_classes.json        # Official Food-101 class registry
│   ├── build_datasets.py           # Dataset generator script
│   ├── dataset_loader.py           # PyTorch Dataset & DataLoader for Kaggle food-101
│   ├── sample_images/              # High-res sample images for testing
│   └── food_history.db             # SQLite database for user meal tracking
├── model/
│   ├── __init__.py
│   ├── architecture.py             # EfficientNet-B0, MobileNetV2, CustomFoodCNN
│   ├── inference.py                # Preprocessing, Top-5 prediction, Saliency Heatmap
│   └── train.py                    # PyTorch training & fine-tuning pipeline
├── nutrition/
│   ├── __init__.py
│   ├── engine.py                   # Nutrition lookup, portion scaling, RDA % calculation
│   └── dietary_advisor.py          # Clinical insights & exercise burn-off calculation
├── backend/
│   ├── __init__.py
│   ├── app.py                      # FastAPI REST application & static file server
│   └── database.py                 # SQLite CRUD operations
├── static/
│   ├── index.html                  # Single Page Application
│   ├── style.css                   # Glassmorphic CSS design system
│   ├── app.js                      # Client logic, webcam, Chart.js charts
│   └── samples/                    # Sample test images for web preview
├── weights/
│   └── build_checkpoint.py         # Checkpoint generator & weight management
├── streamlit_app.py                # Streamlit presentation application
├── test_system.py                  # End-to-end verification script
├── requirements.txt                # Python dependencies
├── run_app.bat                     # 1-Click Windows execution launcher
├── README.md                       # Complete documentation
└── PROJECT_REPORT.md               # Academic university project report
```

---

## 🛠️ Installation & Setup

### Prerequisites
- Python 3.10 or 3.11
- Web browser (Chrome, Edge, Firefox)

### Step 1: Install Dependencies
```bash
pip install -r requirements.txt
```

*(Optional PyTorch CPU install if installing manually)*:
```bash
pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu
```

---

## 💻 Running the Application

### Option A: Using 1-Click Windows Launcher
Double-click `run_app.bat` and select:
- `[1]` to launch the **Modern Web Application** (FastAPI at `http://127.0.0.1:8000`)
- `[2]` to launch the **Academic Streamlit Dashboard** (`http://127.0.0.1:8501`)
- `[3]` to launch the **Food-101 Training Pipeline**

### Option B: Running from Terminal

**1. Launch FastAPI Web Application**:
```bash
uvicorn backend.app:app --host 127.0.0.1 --port 8000 --reload
```
Open your browser at: **`http://127.0.0.1:8000`**

**2. Launch Streamlit Application**:
```bash
streamlit run streamlit_app.py
```
Open your browser at: **`http://127.0.0.1:8501`**

**3. Run Verification Tests**:
```bash
python test_system.py
```

---

## 📊 Dataset & Model Training (Food-101)

The system is configured for the **Food-101** dataset:
- **Kaggle Link**: [dansbecker/food-101](https://www.kaggle.com/datasets/dansbecker/food-101)
- Contains 101 food classes with 1,000 images per category (75,000 training, 25,000 validation).

### Training Command:
```bash
python -m model.train --data_dir /path/to/food-101 --model efficientnet_b0 --epochs 15 --batch_size 32 --lr 0.0001
```

**Training Highlights**:
- **Data Augmentation**: RandomResizedCrop, RandomHorizontalFlip, RandomRotation(15°), ColorJitter.
- **Optimization**: AdamW with Cosine Annealing learning rate schedule.
- **Regularization**: Label smoothing ($0.1$) + Dropout ($p=0.3$).
- **Metrics Tracked**: Cross-Entropy Loss, Top-1 Accuracy, Top-5 Accuracy per epoch.

---

## 📡 REST API Reference

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/health` | Service health, active model, and device information |
| `POST` | `/api/predict` | Multipart image upload for inference and nutrition analysis |
| `POST` | `/api/predict-base64` | Base64 image payload (webcam / drag-and-drop) |
| `POST` | `/api/scale-nutrition` | Rescale nutritional values for custom gram portion |
| `POST` | `/api/history/log` | Save analyzed meal to SQLite database |
| `GET` | `/api/history` | Retrieve user meal history list |
| `DELETE`| `/api/history/{id}` | Delete specific meal from history |
| `DELETE`| `/api/history` | Clear entire meal history |
| `GET` | `/api/dashboard/today` | Today's nutritional totals, goals, and % progress |
| `GET` | `/api/dashboard/trend` | 7-day caloric intake trend data |
| `GET` | `/api/foods` | Catalog list of all 101 foods with nutrition facts |

---

## 📜 Academic Attribution
Developed as part of the Deep Learning & Computer Vision curriculum.
- **T. Kedhar** (24011CSEAI0050)
- **S. Sindhu** (24011CSEAI0047)
- **M. ManiDeepika** (24011CSEAI0138)
