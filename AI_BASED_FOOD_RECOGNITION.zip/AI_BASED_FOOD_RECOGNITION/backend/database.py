"""
Database module for Food Recognition and Nutrition History Tracking
Supports SQLite persistence for meals, daily aggregations, and nutritional goals.
"""

import sqlite3
import os
from datetime import datetime, date
from typing import List, Dict, Any, Optional

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "food_history.db")

def get_connection():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    cursor = conn.cursor()
    
    # Meals history table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS meals (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        food_class TEXT NOT NULL,
        food_name TEXT NOT NULL,
        serving_g REAL NOT NULL,
        calories REAL NOT NULL,
        protein_g REAL NOT NULL,
        carbs_g REAL NOT NULL,
        fat_g REAL NOT NULL,
        fiber_g REAL NOT NULL,
        sodium_mg REAL DEFAULT 0,
        confidence REAL NOT NULL,
        model_name TEXT NOT NULL,
        image_data TEXT,
        meal_type TEXT DEFAULT 'Snack',
        logged_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    
    # User goals table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS user_goals (
        id INTEGER PRIMARY KEY,
        daily_calorie_goal REAL DEFAULT 2000.0,
        daily_protein_goal REAL DEFAULT 60.0,
        daily_carbs_goal REAL DEFAULT 250.0,
        daily_fat_goal REAL DEFAULT 65.0,
        daily_fiber_goal REAL DEFAULT 30.0
    )
    """)
    
    # Insert default goals if not exists
    cursor.execute("SELECT COUNT(*) FROM user_goals")
    if cursor.fetchone()[0] == 0:
        cursor.execute("""
        INSERT INTO user_goals (id, daily_calorie_goal, daily_protein_goal, daily_carbs_goal, daily_fat_goal, daily_fiber_goal)
        VALUES (1, 2000.0, 60.0, 250.0, 65.0, 30.0)
        """)
        
    conn.commit()
    conn.close()

def log_meal(
    food_class: str,
    food_name: str,
    serving_g: float,
    calories: float,
    protein_g: float,
    carbs_g: float,
    fat_g: float,
    fiber_g: float,
    sodium_mg: float = 0.0,
    confidence: float = 0.95,
    model_name: str = "EfficientNet-B0 (Transfer Learning)",
    image_data: Optional[str] = None,
    meal_type: str = "Snack"
) -> int:
    init_db()
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
    INSERT INTO meals (
        food_class, food_name, serving_g, calories, protein_g, carbs_g, fat_g, fiber_g,
        sodium_mg, confidence, model_name, image_data, meal_type, logged_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now', 'localtime'))
    """, (
        food_class, food_name, serving_g, calories, protein_g, carbs_g, fat_g, fiber_g,
        sodium_mg, confidence, model_name, image_data, meal_type
    ))
    meal_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return meal_id

def get_history(limit: int = 50) -> List[Dict[str, Any]]:
    init_db()
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
    SELECT id, food_class, food_name, serving_g, calories, protein_g, carbs_g, fat_g, fiber_g,
           sodium_mg, confidence, model_name, image_data, meal_type, logged_at
    FROM meals
    ORDER BY logged_at DESC
    LIMIT ?
    """, (limit,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def delete_meal(meal_id: int) -> bool:
    init_db()
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM meals WHERE id = ?", (meal_id,))
    deleted = cursor.rowcount > 0
    conn.commit()
    conn.close()
    return deleted

def clear_history() -> bool:
    init_db()
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM meals")
    conn.commit()
    conn.close()
    return True

def get_today_summary() -> Dict[str, Any]:
    init_db()
    conn = get_connection()
    cursor = conn.cursor()
    
    # Query today's totals
    today_str = date.today().isoformat()
    cursor.execute("""
    SELECT 
        COUNT(*) as total_meals,
        COALESCE(SUM(calories), 0) as total_calories,
        COALESCE(SUM(protein_g), 0) as total_protein,
        COALESCE(SUM(carbs_g), 0) as total_carbs,
        COALESCE(SUM(fat_g), 0) as total_fat,
        COALESCE(SUM(fiber_g), 0) as total_fiber,
        COALESCE(SUM(sodium_mg), 0) as total_sodium
    FROM meals
    WHERE date(logged_at) = date('now', 'localtime')
    """)
    totals = dict(cursor.fetchone())
    
    # Get user goals
    cursor.execute("SELECT * FROM user_goals WHERE id = 1")
    goals = dict(cursor.fetchone())
    conn.close()
    
    # Calculate progress %
    c_goal = max(1.0, goals["daily_calorie_goal"])
    p_goal = max(1.0, goals["daily_protein_goal"])
    carb_goal = max(1.0, goals["daily_carbs_goal"])
    f_goal = max(1.0, goals["daily_fat_goal"])
    fiber_goal = max(1.0, goals["daily_fiber_goal"])
    
    progress = {
        "calories_pct": round((totals["total_calories"] / c_goal) * 100, 1),
        "protein_pct": round((totals["total_protein"] / p_goal) * 100, 1),
        "carbs_pct": round((totals["total_carbs"] / carb_goal) * 100, 1),
        "fat_pct": round((totals["total_fat"] / f_goal) * 100, 1),
        "fiber_pct": round((totals["total_fiber"] / fiber_goal) * 100, 1),
        "remaining_calories": round(max(0.0, c_goal - totals["total_calories"]), 1)
    }
    
    return {
        "date": today_str,
        "totals": totals,
        "goals": goals,
        "progress": progress
    }

def get_weekly_trend() -> List[Dict[str, Any]]:
    init_db()
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
    SELECT 
        date(logged_at) as log_date,
        COUNT(*) as meals_count,
        ROUND(SUM(calories), 1) as calories,
        ROUND(SUM(protein_g), 1) as protein,
        ROUND(SUM(carbs_g), 1) as carbs,
        ROUND(SUM(fat_g), 1) as fat
    FROM meals
    WHERE logged_at >= datetime('now', '-7 days', 'localtime')
    GROUP BY date(logged_at)
    ORDER BY date(logged_at) ASC
    """)
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

# Initialize tables immediately
init_db()
