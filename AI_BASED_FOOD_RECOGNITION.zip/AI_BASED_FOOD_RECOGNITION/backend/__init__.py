"""
Backend package for AI-Based Food Recognition and Nutrition Analysis System
"""
