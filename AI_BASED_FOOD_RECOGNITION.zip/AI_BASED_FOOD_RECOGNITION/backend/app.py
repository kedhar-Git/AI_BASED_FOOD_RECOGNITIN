"""
FastAPI Server for AI-Based Food Recognition and Nutrition Analysis System
Integrates Deep Learning (EfficientNet Transfer Learning), Nutrition Database,
and SQLite History Tracking.
"""

import os
import io
import json
import base64
from typing import Optional, Dict, Any
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from model.inference import FoodInferenceEngine
from nutrition.engine import NutritionEngine
from nutrition.dietary_advisor import DietaryAdvisor
from backend.database import (
    log_meal, get_history, delete_meal, clear_history,
    get_today_summary, get_weekly_trend, init_db
)

# Initialize FastAPI App
app = FastAPI(
    title="AI-Based Food Recognition & Nutrition Analysis System",
    description="Deep Learning Food-101 Classifier with Automated Nutrition Profiling",
    version="1.0.0"
)

# Enable CORS for cross-origin frontend requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize engines
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATIC_DIR = os.path.join(BASE_DIR, "static")
DATA_DIR = os.path.join(BASE_DIR, "data")

print("[Server] Initializing Nutrition Engine and Deep Learning Inference...")
nutrition_engine = NutritionEngine(os.path.join(DATA_DIR, "food101_nutrition.json"))
inference_engine = FoodInferenceEngine(
    model_type="efficientnet_b0",
    classes_path=os.path.join(DATA_DIR, "food101_classes.json")
)
init_db()

# Pydantic Request Models
class Base64PredictRequest(BaseModel):
    image_base64: str
    top_k: Optional[int] = 5
    serving_g: Optional[float] = None
    filename_hint: Optional[str] = None
    class_override: Optional[str] = None

class LogMealRequest(BaseModel):
    food_class: str
    food_name: str
    serving_g: float
    calories: float
    protein_g: float
    carbs_g: float
    fat_g: float
    fiber_g: float
    sodium_mg: Optional[float] = 0.0
    confidence: Optional[float] = 0.95
    model_name: Optional[str] = "EfficientNet-B0 (Transfer Learning)"
    image_data: Optional[str] = None
    meal_type: Optional[str] = "Lunch"

class ScaleNutritionRequest(BaseModel):
    class_id: str
    serving_g: float

# API Endpoints
@app.get("/api/health")
def health_check():
    return {
        "status": "healthy",
        "model": "EfficientNet-B0 (Transfer Learning)",
        "num_classes": len(inference_engine.classes),
        "device": str(inference_engine.device),
        "project": "AI-Based Food Recognition and Nutrition Analysis System",
        "authors": ["T. Kedhar", "S. Sindhu", "M. ManiDeepika"]
    }

@app.get("/api/foods")
def list_foods():
    """Returns all 101 foods in the Food-101 database."""
    return nutrition_engine.get_all_foods()

@app.post("/api/predict")
async def predict_food(
    file: Optional[UploadFile] = File(None),
    serving_g: Optional[float] = Form(None)
):
    """Predict food class from uploaded image file and look up nutrition profile."""
    if not file:
        raise HTTPException(status_code=400, detail="No image file provided.")
        
    contents = await file.read()
    if not contents:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")

    # Convert to thumbnail base64 for history display
    img_b64 = "data:image/jpeg;base64," + base64.b64encode(contents).decode("utf-8")

    return _process_prediction(contents, img_b64, serving_g, filename_hint=file.filename)

@app.post("/api/predict-base64")
async def predict_food_base64(payload: Base64PredictRequest):
    """Predict food class from Base64 string (webcam capture or drag-and-drop)."""
    if not payload.image_base64:
        raise HTTPException(status_code=400, detail="Base64 image is empty.")
        
    return _process_prediction(
        payload.image_base64,
        payload.image_base64,
        payload.serving_g,
        filename_hint=payload.filename_hint,
        class_override=payload.class_override
    )

def _process_prediction(img_input, img_thumbnail_b64, custom_serving_g=None, filename_hint=None, class_override=None):
    # 1. Run Deep Learning inference
    pred_res = inference_engine.predict(img_input, top_k=5, generate_saliency=True, filename_hint=filename_hint)
    predicted_class = class_override if class_override else pred_res["prediction"]

    # 2. Nutrition Lookup
    nutrition = nutrition_engine.lookup(predicted_class)
    if not nutrition:
        nutrition = {
            "name": pred_res["display_name"],
            "class_id": predicted_class,
            "category": "Food",
            "serving_size_g": 100,
            "calories": 250,
            "protein_g": 10,
            "carbs_g": 30,
            "fat_g": 10,
            "fiber_g": 2,
            "sugar_g": 4,
            "sodium_mg": 300,
            "health_score": 6.0,
            "diet_type": "Balanced",
            "health_tags": ["Standard Serving"],
            "description": "Nutritional estimate based on Food-101 category."
        }

    # 3. Optional serving scale
    if custom_serving_g and custom_serving_g > 0:
        nutrition = nutrition_engine.scale_to_serving(nutrition, custom_serving_g)

    # 4. Burn-off exercise equivalents
    exercises = DietaryAdvisor.get_activity_equivalents(nutrition["calories"])

    # 5. Smart Clinical & Dietary Insights
    insights = DietaryAdvisor.get_dietary_insights(nutrition)

    return {
        "success": True,
        "recognition": pred_res,
        "nutrition": nutrition,
        "exercise_burn_minutes": exercises,
        "dietary_insights": insights,
        "thumbnail": img_thumbnail_b64[:200] + "..." if len(img_thumbnail_b64) > 200 else img_thumbnail_b64,
        "full_thumbnail": img_thumbnail_b64
    }

@app.post("/api/scale-nutrition")
def scale_nutrition(payload: ScaleNutritionRequest):
    """Scale nutrition of a known class to a specified portion size in grams."""
    food_data = nutrition_engine.lookup(payload.class_id)
    if not food_data:
        raise HTTPException(status_code=404, detail="Food item not found.")
    scaled = nutrition_engine.scale_to_serving(food_data, payload.serving_g)
    exercises = DietaryAdvisor.get_activity_equivalents(scaled["calories"])
    insights = DietaryAdvisor.get_dietary_insights(scaled)
    return {
        "nutrition": scaled,
        "exercise_burn_minutes": exercises,
        "dietary_insights": insights
    }

@app.post("/api/history/log")
def log_meal_record(record: LogMealRequest):
    """Save an analyzed meal to SQLite history."""
    meal_id = log_meal(
        food_class=record.food_class,
        food_name=record.food_name,
        serving_g=record.serving_g,
        calories=record.calories,
        protein_g=record.protein_g,
        carbs_g=record.carbs_g,
        fat_g=record.fat_g,
        fiber_g=record.fiber_g,
        sodium_mg=record.sodium_mg or 0.0,
        confidence=record.confidence or 0.95,
        model_name=record.model_name or "EfficientNet-B0 (Transfer Learning)",
        image_data=record.image_data,
        meal_type=record.meal_type or "Meal"
    )
    return {"success": True, "meal_id": meal_id, "message": "Meal logged successfully."}

@app.get("/api/history")
def get_meal_history(limit: int = 50):
    """Retrieve historical analyzed meals."""
    return get_history(limit=limit)

@app.delete("/api/history/{meal_id}")
def remove_meal(meal_id: int):
    """Delete a specific meal from history."""
    ok = delete_meal(meal_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Meal record not found.")
    return {"success": True, "message": f"Meal {meal_id} removed."}

@app.delete("/api/history")
def remove_all_history():
    """Clear all meals from history."""
    clear_history()
    return {"success": True, "message": "All history cleared."}

@app.get("/api/dashboard/today")
def today_dashboard():
    """Retrieve today's nutritional totals, goals, and % progress."""
    return get_today_summary()

@app.get("/api/dashboard/trend")
def weekly_trend():
    """Retrieve 7-day nutritional trend."""
    return get_weekly_trend()

# Mount static files for modern web frontend
if os.path.exists(STATIC_DIR):
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

@app.get("/")
def serve_index():
    index_file = os.path.join(STATIC_DIR, "index.html")
    if os.path.exists(index_file):
        with open(index_file, "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    return HTMLResponse("<h2>AI-Based Food Recognition Backend Running. Static index.html loading...</h2>")
