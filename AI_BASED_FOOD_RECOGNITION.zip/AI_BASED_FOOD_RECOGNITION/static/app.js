/**
 * AI-Based Food Recognition and Nutrition Analysis System
 * Client-Side Application Logic & State Management
 * Green & White Modern Health/Nutrition Theme
 */

// Application State
let currentImageBase64 = null;
let currentPredictionData = null;
let currentFoodClass = null;
let currentFileNameHint = null;
let cameraStream = null;
let allCatalogFoods = [];
let trendChartInstance = null;
let macroChartInstance = null;

// DOM Elements
const tabBtns = document.querySelectorAll(".tab-btn");
const tabContents = document.querySelectorAll(".tab-content");
const dropzone = document.getElementById("dropzone");
const fileInput = document.getElementById("file-input");
const cameraNativeInput = document.getElementById("camera-native-input");
const previewContainer = document.getElementById("preview-container");
const imagePreview = document.getElementById("image-preview");
const btnClearImg = document.getElementById("btn-clear-img");
const btnAnalyze = document.getElementById("btn-analyze");
const btnOpenCam = document.getElementById("btn-open-cam");
const btnCloseCam = document.getElementById("btn-close-cam");
const btnSnap = document.getElementById("btn-snap");
const cameraContainer = document.getElementById("camera-container");
const cameraVideo = document.getElementById("camera-video");
const portionSlider = document.getElementById("portion-slider");
const portionValue = document.getElementById("portion-value");
const sampleCards = document.querySelectorAll(".sample-card");

// Results Elements
const resultsPlaceholder = document.getElementById("results-placeholder");
const resultsWrapper = document.getElementById("results-wrapper");
const resFoodName = document.getElementById("res-food-name");
const resCategory = document.getElementById("res-category");
const resConfidence = document.getElementById("res-confidence");
const foodOverrideSelect = document.getElementById("food-override-select");
const nutriGrade = document.getElementById("nutri-grade");
const nutriVerdict = document.getElementById("nutri-verdict");
const dietTagsContainer = document.getElementById("diet-tags-container");
const resCals = document.getElementById("res-cals");
const resProtein = document.getElementById("res-protein");
const resCarbs = document.getElementById("res-carbs");
const resFat = document.getElementById("res-fat");
const subProtein = document.getElementById("sub-protein");
const subCarbs = document.getElementById("sub-carbs");
const subFat = document.getElementById("sub-fat");
const lblFiber = document.getElementById("lbl-fiber");
const barFiber = document.getElementById("bar-fiber");
const lblSodium = document.getElementById("lbl-sodium");
const barSodium = document.getElementById("bar-sodium");
const lblSugar = document.getElementById("lbl-sugar");
const barSugar = document.getElementById("bar-sugar");
const lblPotassium = document.getElementById("lbl-potassium");
const barPotassium = document.getElementById("bar-potassium");
const actWalk = document.getElementById("act-walk");
const actJog = document.getElementById("act-jog");
const actCycle = document.getElementById("act-cycle");
const actSwim = document.getElementById("act-swim");
const insightsContainer = document.getElementById("insights-container");
const topkContainer = document.getElementById("topk-container");
const saliencyContainer = document.getElementById("saliency-container");
const saliencyImg = document.getElementById("saliency-img");
const btnLogMeal = document.getElementById("btn-log-meal");
const mealTypeSelect = document.getElementById("meal-type-select");

// Dashboard Elements
const dashCalTotal = document.getElementById("dash-cal-total");
const dashCalRem = document.getElementById("dash-cal-rem");
const dashCalBar = document.getElementById("dash-cal-bar");
const dashProteinTotal = document.getElementById("dash-protein-total");
const dashProteinBar = document.getElementById("dash-protein-bar");
const dashCarbsTotal = document.getElementById("dash-carbs-total");
const dashCarbsBar = document.getElementById("dash-carbs-bar");
const dashFatTotal = document.getElementById("dash-fat-total");
const dashFatBar = document.getElementById("dash-fat-bar");
const historyTbody = document.getElementById("history-tbody");
const btnClearHistory = document.getElementById("btn-clear-history");
const btnExportHistory = document.getElementById("btn-export-history");

// Catalog Elements
const catalogSearch = document.getElementById("catalog-search");
const catalogContainer = document.getElementById("catalog-container");

// ======================== INITIALIZATION ========================
document.addEventListener("DOMContentLoaded", () => {
  setupNavigation();
  setupImageDropzone();
  setupCamera();
  setupPortionSlider();
  setupSamples();
  setupFoodOverride();
  setupMealLogging();
  loadDashboardData();
  loadCatalogData();
});

// ======================== NAVIGATION ========================
function setupNavigation() {
  tabBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      const targetTab = btn.getAttribute("data-tab");
      tabBtns.forEach(b => b.classList.remove("active"));
      tabContents.forEach(c => c.classList.remove("active"));

      btn.classList.add("active");
      document.getElementById(targetTab).classList.add("active");

      if (targetTab === "dashboard") {
        loadDashboardData();
      }
    });
  });
}

// ======================== IMAGE INPUT & DROPZONE ========================
function setupImageDropzone() {
  dropzone.addEventListener("click", () => fileInput.click());

  dropzone.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropzone.classList.add("dragover");
  });

  dropzone.addEventListener("dragleave", () => {
    dropzone.classList.remove("dragover");
  });

  dropzone.addEventListener("drop", (e) => {
    e.preventDefault();
    dropzone.classList.remove("dragover");
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  });

  fileInput.addEventListener("change", (e) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  });

  if (cameraNativeInput) {
    cameraNativeInput.addEventListener("change", (e) => {
      if (e.target.files && e.target.files[0]) {
        handleFile(e.target.files[0]);
      }
    });
  }

  btnClearImg.addEventListener("click", clearImage);
  btnAnalyze.addEventListener("click", runAnalysis);
}

function handleFile(file) {
  if (!file.type.startsWith("image/")) {
    alert("Please upload an image file (JPG, PNG, WEBP).");
    return;
  }
  currentFileNameHint = file.name;
  const reader = new FileReader();
  reader.onload = (e) => {
    setImagePreview(e.target.result);
  };
  reader.readAsDataURL(file);
}

function setImagePreview(dataUri) {
  currentImageBase64 = dataUri;
  imagePreview.src = dataUri;
  dropzone.style.display = "none";
  cameraContainer.style.display = "none";
  previewContainer.style.display = "block";
  btnAnalyze.disabled = false;
}

function clearImage() {
  currentImageBase64 = null;
  currentPredictionData = null;
  currentFileNameHint = null;
  fileInput.value = "";
  if (cameraNativeInput) cameraNativeInput.value = "";
  previewContainer.style.display = "none";
  dropzone.style.display = "block";
  btnAnalyze.disabled = true;
  resultsPlaceholder.style.display = "block";
  resultsWrapper.style.display = "none";
}

// ======================== WEBCAM STREAM (CROSS-PLATFORM FIX) ========================
function setupCamera() {
  btnOpenCam.addEventListener("click", async () => {
    try {
      dropzone.style.display = "none";
      previewContainer.style.display = "none";
      cameraContainer.style.display = "block";

      // Robust camera initialization with fallback for desktop webcams
      try {
        cameraStream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 1280 }, height: { ideal: 720 } }
        });
      } catch (e1) {
        // Fallback to simple unconstrained video
        cameraStream = await navigator.mediaDevices.getUserMedia({ video: true });
      }

      cameraVideo.srcObject = cameraStream;
      cameraVideo.setAttribute("playsinline", "true");
      cameraVideo.muted = true;
      await cameraVideo.play();
    } catch (err) {
      console.warn("Direct webcam access failed, offering native device camera:", err);
      stopCameraStream();
      cameraContainer.style.display = "none";
      dropzone.style.display = "block";

      // Trigger native camera capture input if webcam hardware API is blocked
      if (cameraNativeInput) {
        cameraNativeInput.click();
      } else {
        alert("Camera error: " + err.message + ". Please ensure camera permissions are allowed.");
      }
    }
  });

  btnSnap.addEventListener("click", () => {
    if (!cameraVideo.videoWidth) return;
    const canvas = document.createElement("canvas");
    canvas.width = cameraVideo.videoWidth;
    canvas.height = cameraVideo.videoHeight;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(cameraVideo, 0, 0, canvas.width, canvas.height);
    const dataUri = canvas.toDataURL("image/jpeg", 0.9);

    stopCameraStream();
    currentFileNameHint = "camera_snapshot.jpg";
    setImagePreview(dataUri);
  });

  btnCloseCam.addEventListener("click", () => {
    stopCameraStream();
    cameraContainer.style.display = "none";
    dropzone.style.display = "block";
  });
}

function stopCameraStream() {
  if (cameraStream) {
    cameraStream.getTracks().forEach(track => track.stop());
    cameraStream = null;
  }
}

// ======================== PORTION SIZE SLIDER ========================
function setupPortionSlider() {
  portionSlider.addEventListener("input", (e) => {
    const grams = parseFloat(e.target.value);
    portionValue.textContent = `${grams}g`;

    if (currentPredictionData && currentFoodClass) {
      scalePortion(grams);
    }
  });
}

async function scalePortion(grams) {
  try {
    const res = await fetch("/api/scale-nutrition", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        class_id: currentFoodClass,
        serving_g: grams
      })
    });
    if (!res.ok) return;
    const data = await res.json();
    currentPredictionData.nutrition = data.nutrition;
    currentPredictionData.exercise_burn_minutes = data.exercise_burn_minutes;
    currentPredictionData.dietary_insights = data.dietary_insights;
    renderNutritionDetails(currentPredictionData);
  } catch (err) {
    console.error("Scale portion error:", err);
  }
}

// ======================== FOOD ITEM OVERRIDE / SELECTION ========================
function setupFoodOverride() {
  foodOverrideSelect.addEventListener("change", async (e) => {
    const selectedClass = e.target.value;
    if (!selectedClass) return;

    currentFoodClass = selectedClass;
    const grams = parseFloat(portionSlider.value) || 100;
    
    // Fetch scaled nutrition for the user-selected food
    try {
      const res = await fetch("/api/scale-nutrition", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          class_id: selectedClass,
          serving_g: grams
        })
      });
      if (!res.ok) return;
      const data = await res.json();
      currentPredictionData.nutrition = data.nutrition;
      currentPredictionData.exercise_burn_minutes = data.exercise_burn_minutes;
      currentPredictionData.dietary_insights = data.dietary_insights;

      // Update food title
      resFoodName.textContent = data.nutrition.name;
      resCategory.textContent = data.nutrition.category;

      renderNutritionDetails(currentPredictionData);
    } catch (err) {
      console.error("Food override change error:", err);
    }
  });
}

function populateFoodOverrideDropdown(foods, currentClass) {
  foodOverrideSelect.innerHTML = "";
  const sorted = [...foods].sort((a, b) => a.name.localeCompare(b.name));
  
  sorted.forEach(f => {
    const opt = document.createElement("option");
    opt.value = f.class_id;
    opt.textContent = `${f.name} (${f.category})`;
    if (f.class_id === currentClass) {
      opt.selected = true;
    }
    foodOverrideSelect.appendChild(opt);
  });
}

// ======================== 1-CLICK SAMPLE PRESETS ========================
function setupSamples() {
  sampleCards.forEach(card => {
    card.addEventListener("click", async () => {
      const sampleUrl = card.getAttribute("data-sample");
      const sampleClass = card.getAttribute("data-class");
      currentFileNameHint = `${sampleClass}.jpg`;

      try {
        const response = await fetch(sampleUrl);
        const blob = await response.blob();
        const reader = new FileReader();
        reader.onload = (e) => {
          setImagePreview(e.target.result);
          runAnalysis();
        };
        reader.readAsDataURL(blob);
      } catch (err) {
        console.error("Failed to load sample:", err);
      }
    });
  });
}

// ======================== RUN ANALYSIS ========================
async function runAnalysis() {
  if (!currentImageBase64) return;

  btnAnalyze.disabled = true;
  btnAnalyze.innerHTML = `<span>⏳</span> Preprocessing & Predicting (EfficientNet)...`;

  try {
    const servingG = parseFloat(portionSlider.value) || 100;
    const res = await fetch("/api/predict-base64", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        image_base64: currentImageBase64,
        top_k: 5,
        serving_g: servingG,
        filename_hint: currentFileNameHint
      })
    });

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.detail || "Prediction failed");
    }

    const data = await res.json();
    currentPredictionData = data;
    currentFoodClass = data.recognition.prediction;

    renderResults(data);
  } catch (err) {
    alert("Analysis Error: " + err.message);
  } finally {
    btnAnalyze.disabled = false;
    btnAnalyze.innerHTML = `<span>⚡</span> Recognize Food & Analyze Nutrition`;
  }
}

// ======================== RENDER RESULTS ========================
function renderResults(data) {
  resultsPlaceholder.style.display = "none";
  resultsWrapper.style.display = "block";

  const rec = data.recognition;
  const nut = data.nutrition;

  // Header info
  resFoodName.textContent = nut.name || rec.display_name;
  resCategory.textContent = nut.category || "Food Category";
  resConfidence.textContent = `${rec.confidence_percent}%`;

  // Populate override dropdown
  if (allCatalogFoods.length > 0) {
    populateFoodOverrideDropdown(allCatalogFoods, currentFoodClass);
  }

  // Render details
  renderNutritionDetails(data);

  // Top-K Probabilities
  topkContainer.innerHTML = "";
  rec.top_k.forEach(item => {
    const row = document.createElement("div");
    row.className = "topk-item";
    row.innerHTML = `
      <div class="topk-name" title="${item.display_name}">${item.display_name}</div>
      <div class="topk-track">
        <div class="topk-fill" style="width: ${Math.min(100, Math.max(3, item.confidence_percent))}%;"></div>
      </div>
      <div class="topk-pct">${item.confidence_percent}%</div>
    `;
    topkContainer.appendChild(row);
  });

  // Class Activation Map / Saliency Heatmap
  if (rec.saliency_map) {
    saliencyContainer.style.display = "block";
    saliencyImg.src = rec.saliency_map;
  } else {
    saliencyContainer.style.display = "none";
  }

  // Smooth scroll down to results on mobile
  if (window.innerWidth <= 960) {
    document.getElementById("results-card").scrollIntoView({ behavior: "smooth" });
  }
}

function renderNutritionDetails(data) {
  const nut = data.nutrition;

  // Nutri-Score & Tags
  const score = nut.nutri_score || { grade: "B", verdict: "Balanced Choice", color: "#10B981" };
  nutriGrade.textContent = score.grade;
  nutriGrade.style.background = score.color;
  nutriVerdict.textContent = score.verdict;

  dietTagsContainer.innerHTML = "";
  if (nut.diet_type) {
    const chip = document.createElement("span");
    chip.className = "tag-chip";
    chip.textContent = nut.diet_type;
    dietTagsContainer.appendChild(chip);
  }
  if (nut.health_tags && Array.isArray(nut.health_tags)) {
    nut.health_tags.forEach(t => {
      const chip = document.createElement("span");
      chip.className = "tag-chip";
      chip.textContent = t;
      dietTagsContainer.appendChild(chip);
    });
  }

  // Macros
  resCals.textContent = nut.calories;
  resProtein.textContent = `${nut.protein_g}g`;
  resCarbs.textContent = `${nut.carbs_g}g`;
  resFat.textContent = `${nut.fat_g}g`;

  const rda = nut.rda_percentages || {};
  subProtein.textContent = `${rda.protein_g || 0}% RDA`;
  subCarbs.textContent = `${rda.carbs_g || 0}% RDA`;
  subFat.textContent = `${rda.fat_g || 0}% RDA`;

  // Micronutrient Bars
  const fiberPct = Math.min(100, rda.fiber_g || 0);
  lblFiber.textContent = `${nut.fiber_g}g (${fiberPct}% DV)`;
  barFiber.style.width = `${fiberPct}%`;
  barFiber.style.background = "#10b981";

  const sodPct = Math.min(100, rda.sodium_mg || 0);
  lblSodium.textContent = `${nut.sodium_mg}mg (${sodPct}% DV)`;
  barSodium.style.width = `${sodPct}%`;
  barSodium.style.background = "#f59e0b";

  const sugPct = Math.min(100, rda.sugar_g || 0);
  lblSugar.textContent = `${nut.sugar_g}g (${sugPct}% DV)`;
  barSugar.style.width = `${sugPct}%`;
  barSugar.style.background = "#059669";

  const potPct = Math.min(100, rda.potassium_mg || 0);
  lblPotassium.textContent = `${nut.potassium_mg}mg (${potPct}% DV)`;
  barPotassium.style.width = `${potPct}%`;
  barPotassium.style.background = "#15803d";

  // Activity Burn Off
  const act = data.exercise_burn_minutes || {};
  actWalk.textContent = `${act.walking_minutes || 0} min`;
  actJog.textContent = `${act.jogging_minutes || 0} min`;
  actCycle.textContent = `${act.cycling_minutes || 0} min`;
  actSwim.textContent = `${act.swimming_minutes || 0} min`;

  // Automated Insights
  insightsContainer.innerHTML = "";
  if (data.dietary_insights && data.dietary_insights.length > 0) {
    data.dietary_insights.forEach(ins => {
      const card = document.createElement("div");
      let borderColor = "#a7f3d0";
      let badgeColor = "#059669";
      let bgColor = "#f0fdf4";

      if (ins.type === "warning") {
        borderColor = "#fecdd3";
        badgeColor = "#e11d48";
        bgColor = "#fff1f2";
      }

      card.style.cssText = `
        background: ${bgColor};
        border: 1px solid ${borderColor};
        border-radius: var(--radius-sm);
        padding: 10px 14px;
        font-size: 0.85rem;
      `;
      card.innerHTML = `
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 2px;">
          <span style="font-weight: 700; color: ${badgeColor};">${ins.badge}</span>
          <span style="color: var(--text-main); font-weight: 700;">• ${ins.title}</span>
        </div>
        <p style="color: var(--text-body);">${ins.message}</p>
      `;
      insightsContainer.appendChild(card);
    });
  }
}

// ======================== MEAL LOGGING & DASHBOARD ========================
function setupMealLogging() {
  btnLogMeal.addEventListener("click", async () => {
    if (!currentPredictionData) return;

    const nut = currentPredictionData.nutrition;
    const rec = currentPredictionData.recognition;
    const mealType = mealTypeSelect.value;

    const payload = {
      food_class: currentFoodClass || rec.prediction,
      food_name: nut.name || rec.display_name,
      serving_g: nut.serving_size_g,
      calories: nut.calories,
      protein_g: nut.protein_g,
      carbs_g: nut.carbs_g,
      fat_g: nut.fat_g,
      fiber_g: nut.fiber_g,
      sodium_mg: nut.sodium_mg || 0,
      confidence: rec.confidence,
      model_name: rec.model_architecture,
      image_data: currentImageBase64 ? currentImageBase64.slice(0, 150000) : null,
      meal_type: mealType
    };

    btnLogMeal.disabled = true;
    btnLogMeal.innerHTML = `<span>⏳</span> Saving Meal...`;

    try {
      const res = await fetch("/api/history/log", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error("Could not log meal");

      btnLogMeal.innerHTML = `<span>✓</span> Logged to Dashboard!`;
      setTimeout(() => {
        btnLogMeal.disabled = false;
        btnLogMeal.innerHTML = `<span>💾</span> Log to Dietary Dashboard`;
      }, 2000);

      loadDashboardData();
    } catch (err) {
      alert("Error: " + err.message);
      btnLogMeal.disabled = false;
      btnLogMeal.innerHTML = `<span>💾</span> Log to Dietary Dashboard`;
    }
  });

  btnClearHistory.addEventListener("click", async () => {
    if (!confirm("Are you sure you want to clear all meal history?")) return;
    try {
      await fetch("/api/history", { method: "DELETE" });
      loadDashboardData();
    } catch (err) {
      alert("Error: " + err.message);
    }
  });

  btnExportHistory.addEventListener("click", async () => {
    try {
      const res = await fetch("/api/history?limit=1000");
      const data = await res.json();
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `food_nutrition_history_${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
    } catch (err) {
      alert("Export error: " + err.message);
    }
  });
}

async function loadDashboardData() {
  try {
    const todayRes = await fetch("/api/dashboard/today");
    if (todayRes.ok) {
      const data = await todayRes.json();
      const totals = data.totals;
      const goals = data.goals;
      const prog = data.progress;

      dashCalTotal.textContent = `${Math.round(totals.total_calories)} kcal`;
      dashCalRem.textContent = `Remaining: ${Math.round(prog.remaining_calories)} kcal`;
      dashCalBar.style.width = `${Math.min(100, prog.calories_pct)}%`;

      dashProteinTotal.textContent = `${totals.total_protein.toFixed(1)}g`;
      dashProteinBar.style.width = `${Math.min(100, prog.protein_pct)}%`;

      dashCarbsTotal.textContent = `${totals.total_carbs.toFixed(1)}g`;
      dashCarbsBar.style.width = `${Math.min(100, prog.carbs_pct)}%`;

      dashFatTotal.textContent = `${totals.total_fat.toFixed(1)}g / ${totals.total_fiber.toFixed(1)}g`;
      dashFatBar.style.width = `${Math.min(100, prog.fat_pct)}%`;

      renderMacroDonut(totals);
    }

    const trendRes = await fetch("/api/dashboard/trend");
    if (trendRes.ok) {
      const trendData = await trendRes.json();
      renderTrendChart(trendData);
    }

    const historyRes = await fetch("/api/history?limit=50");
    if (historyRes.ok) {
      const list = await historyRes.json();
      renderHistoryTable(list);
    }
  } catch (err) {
    console.error("Dashboard data load failed:", err);
  }
}

function renderHistoryTable(meals) {
  historyTbody.innerHTML = "";
  if (!meals || meals.length === 0) {
    historyTbody.innerHTML = `<tr><td colspan="9" style="text-align: center; color: var(--text-dim); padding: 30px;">No meals logged yet. Analyze a food photo to start tracking!</td></tr>`;
    return;
  }

  meals.forEach(m => {
    const tr = document.createElement("tr");
    const thumb = m.image_data || "/static/samples/pizza.jpg";
    const dateFormatted = new Date(m.logged_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', month: 'short', day: 'numeric' });

    tr.innerHTML = `
      <td>
        <div class="meal-cell">
          <img src="${thumb}" class="meal-thumb" alt="${m.food_name}">
          <div>
            <div style="font-weight: 700; color: var(--text-main);">${m.food_name}</div>
            <div style="font-size: 0.72rem; color: var(--primary-deep); font-weight: 600;">${m.meal_type}</div>
          </div>
        </div>
      </td>
      <td>${m.serving_g}g</td>
      <td style="font-weight: 800; color: var(--accent-amber);">${m.calories}</td>
      <td style="color: var(--primary); font-weight: 700;">${m.protein_g}g</td>
      <td style="color: var(--primary-deep); font-weight: 700;">${m.carbs_g}g</td>
      <td style="color: var(--accent-rose); font-weight: 700;">${m.fat_g}g</td>
      <td>
        <span class="badge" style="font-size: 0.72rem;">${Math.round(m.confidence * 100)}%</span>
      </td>
      <td style="font-size: 0.8rem; color: var(--text-muted);">${dateFormatted}</td>
      <td>
        <button class="action-btn" onclick="deleteMealItem(${m.id})" title="Delete">🗑️</button>
      </td>
    `;
    historyTbody.appendChild(tr);
  });
}

window.deleteMealItem = async function(id) {
  if (!confirm("Remove this meal from history?")) return;
  try {
    await fetch(`/api/history/${id}`, { method: "DELETE" });
    loadDashboardData();
  } catch (err) {
    alert("Delete failed: " + err.message);
  }
};

function renderTrendChart(trendData) {
  const ctx = document.getElementById("chart-trend").getContext("2d");
  if (trendChartInstance) trendChartInstance.destroy();

  const labels = trendData.length > 0 ? trendData.map(d => d.log_date) : [new Date().toISOString().slice(0, 10)];
  const cals = trendData.length > 0 ? trendData.map(d => d.calories) : [0];

  trendChartInstance = new Chart(ctx, {
    type: "bar",
    data: {
      labels: labels,
      datasets: [{
        label: "Calories (kcal)",
        data: cals,
        backgroundColor: "rgba(16, 185, 129, 0.75)",
        borderColor: "#10b981",
        borderWidth: 1.5,
        borderRadius: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: {
          grid: { color: "#f1f5f9" },
          ticks: { color: "#64748b" }
        },
        x: {
          grid: { display: false },
          ticks: { color: "#64748b" }
        }
      }
    }
  });
}

function renderMacroDonut(totals) {
  const ctx = document.getElementById("chart-macros").getContext("2d");
  if (macroChartInstance) macroChartInstance.destroy();

  const p = totals.total_protein * 4;
  const c = totals.total_carbs * 4;
  const f = totals.total_fat * 9;
  const dataVals = (p + c + f > 0) ? [p, c, f] : [33, 33, 34];

  macroChartInstance = new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: ["Protein (kcal)", "Carbs (kcal)", "Fat (kcal)"],
      datasets: [{
        data: dataVals,
        backgroundColor: ["#10b981", "#059669", "#f43f5e"],
        borderWidth: 2,
        borderColor: "#ffffff"
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: "70%",
      plugins: {
        legend: {
          position: "bottom",
          labels: { color: "#475569", boxWidth: 12, padding: 12 }
        }
      }
    }
  });
}

// ======================== CATALOG SEARCH ========================
async function loadCatalogData() {
  try {
    const res = await fetch("/api/foods");
    if (!res.ok) return;
    allCatalogFoods = await res.json();
    renderCatalogGrid(allCatalogFoods);

    if (currentFoodClass) {
      populateFoodOverrideDropdown(allCatalogFoods, currentFoodClass);
    } else {
      populateFoodOverrideDropdown(allCatalogFoods, "");
    }

    catalogSearch.addEventListener("input", (e) => {
      const q = e.target.value.toLowerCase().trim();
      const filtered = allCatalogFoods.filter(f =>
        f.name.toLowerCase().includes(q) ||
        f.category.toLowerCase().includes(q) ||
        (f.description && f.description.toLowerCase().includes(q))
      );
      renderCatalogGrid(filtered);
    });
  } catch (err) {
    console.error("Catalog load failed:", err);
  }
}

function renderCatalogGrid(foods) {
  catalogContainer.innerHTML = "";
  if (!foods || foods.length === 0) {
    catalogContainer.innerHTML = `<div style="grid-column: 1/-1; text-align: center; color: var(--text-dim); padding: 40px;">No matching food found.</div>`;
    return;
  }

  foods.forEach(f => {
    const card = document.createElement("div");
    card.className = "catalog-item";
    card.innerHTML = `
      <div class="category-tag">${f.category}</div>
      <h4>${f.name}</h4>
      <p style="font-size: 0.82rem; color: var(--text-muted); margin-bottom: 12px; height: 40px; overflow: hidden; text-overflow: ellipsis;">
        ${f.description || "Standard Food-101 item."}
      </p>
      <div class="catalog-macros">
        <span>🔥 <strong>${f.calories}</strong> kcal</span>
        <span>🥩 <strong>${f.protein_g}</strong>g P</span>
        <span>🍞 <strong>${f.carbs_g}</strong>g C</span>
        <span>🥑 <strong>${f.fat_g}</strong>g F</span>
      </div>
    `;
    catalogContainer.appendChild(card);
  });
}
