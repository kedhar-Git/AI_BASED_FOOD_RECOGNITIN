from model.inference import FoodInferenceEngine
from nutrition.engine import NutritionEngine

inf = FoodInferenceEngine(model_type='efficientnet_b0')
nut = NutritionEngine()

samples = [
    ('data/sample_images/chicken_curry.jpg', 'Chicken Biryani / Curry'),
    ('data/sample_images/pizza.jpg', 'Artisan Pizza'),
    ('data/sample_images/caesar_salad.jpg', 'Caesar Salad'),
    ('data/sample_images/sushi.jpg', 'Salmon Sushi')
]

print("================= MULTI-IMAGE PREDICTION TEST =================")
for path, label in samples:
    pred = inf.predict(path)
    food_data = nut.lookup(pred['prediction'])
    print(f"Sample: {label}")
    print(f"  -> Predicted: {pred['prediction']} ({pred['confidence_percent']}%)")
    print(f"  -> Nutrition Fact: {food_data['name']}")
    print(f"  -> Calories: {food_data['calories']} kcal | Protein: {food_data['protein_g']}g | Carbs: {food_data['carbs_g']}g | Fat: {food_data['fat_g']}g")
    print("-----------------------------------------------------------------")
