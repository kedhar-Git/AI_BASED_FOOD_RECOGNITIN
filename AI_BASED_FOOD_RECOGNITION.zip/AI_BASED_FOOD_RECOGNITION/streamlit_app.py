"""
AI-Based Food Recognition and Nutrition Analysis System
Interactive Academic Streamlit Application
Authors:
  - T. Kedhar (URN: 24011CSEAI0050)
  - S. Sindhu (URN: 24011CSEAI0047)
  - M. ManiDeepika (URN: 24011CSEAI0138)
"""

import os
import streamlit as st
from PIL import Image
import pandas as pd

from model.inference import FoodInferenceEngine
from nutrition.engine import NutritionEngine
from nutrition.dietary_advisor import DietaryAdvisor
from backend.database import log_meal, get_history, get_today_summary, clear_history

# Page Configuration
st.set_page_config(
    page_title="AI Food Recognition & Nutrition Analysis",
    page_icon="🥗",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styling
st.markdown("""
<style>
    .main-title {
        font-size: 2.2rem;
        font-weight: 800;
        background: linear-gradient(135deg, #6366f1, #10b981);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 0.2rem;
    }
    .author-badge {
        font-size: 0.85rem;
        color: #9ca3af;
        margin-bottom: 1.5rem;
    }
    .metric-card {
        background-color: #1f2937;
        padding: 1rem;
        border-radius: 0.5rem;
        border: 1px solid rgba(255,255,255,0.08);
        text-align: center;
    }
</style>
""", unsafe_allow_html=True)

# Cache Engines
@st.cache_resource
def load_engines():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    nutrition = NutritionEngine(os.path.join(base_dir, "data", "food101_nutrition.json"))
    inference = FoodInferenceEngine(
        model_type="efficientnet_b0",
        classes_path=os.path.join(base_dir, "data", "food101_classes.json")
    )
    return nutrition, inference

nutrition_engine, inference_engine = load_engines()

# Header
st.markdown('<div class="main-title">AI-Based Food Recognition and Nutrition Analysis System</div>', unsafe_allow_html=True)

# Sidebar
st.sidebar.title("Navigation & Settings")
app_mode = st.sidebar.radio("Select View", ["📸 AI Food Scanner", "📈 Dietary History Dashboard", "🥗 Food-101 Catalog", "🧠 Architecture & Flow"])

serving_grams = st.sidebar.slider("Portion Size (grams)", min_value=25, max_value=500, value=100, step=25)

# VIEW 1: SCANNER
if app_mode == "📸 AI Food Scanner":
    col_input, col_results = st.columns([1, 1.2])

    image_to_process = None

    with col_input:
        st.subheader("1. Food Image Acquisition")
        input_method = st.radio("Choose Input Method", ["Upload Image", "Live Webcam", "Test Sample Presets"], horizontal=True)

        if input_method == "Upload Image":
            uploaded_file = st.file_uploader("Upload a food photo", type=["jpg", "jpeg", "png", "webp"])
            if uploaded_file:
                image_to_process = Image.open(uploaded_file).convert("RGB")
                st.image(image_to_process, caption="Uploaded Image", use_container_width=True)

        elif input_method == "Live Webcam":
            camera_file = st.camera_input("Take a photo of food")
            if camera_file:
                image_to_process = Image.open(camera_file).convert("RGB")
                st.image(image_to_process, caption="Captured Frame", use_container_width=True)

        elif input_method == "Test Sample Presets":
            samples_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "sample_images")
            sample_options = {
                "Chicken Biryani / Curry": "chicken_curry.jpg",
                "Artisan Pizza": "pizza.jpg",
                "Caesar Salad": "caesar_salad.jpg",
                "Salmon Sushi": "sushi.jpg"
            }
            chosen_sample = st.selectbox("Select Benchmark Food Sample", list(sample_options.keys()))
            sample_path = os.path.join(samples_dir, sample_options[chosen_sample])
            if os.path.exists(sample_path):
                image_to_process = Image.open(sample_path).convert("RGB")
                st.image(image_to_process, caption=f"Sample: {chosen_sample}", use_container_width=True)

    with col_results:
        st.subheader("2. Deep Learning & Nutrition Profile")
        if image_to_process is not None:
            with st.spinner("Processing image through EfficientNet-B0 (Food-101)..."):
                # Run inference
                prediction = inference_engine.predict(image_to_process, top_k=5, generate_saliency=True)
                pred_class = prediction["prediction"]
                confidence_pct = prediction["confidence_percent"]

                # Lookup nutrition
                food_info = nutrition_engine.lookup(pred_class)
                if not food_info:
                    food_info = {
                        "name": prediction["display_name"],
                        "category": "Food",
                        "serving_size_g": 100,
                        "calories": 250, "protein_g": 10, "carbs_g": 30, "fat_g": 10,
                        "fiber_g": 2, "sugar_g": 4, "sodium_mg": 300, "health_score": 6.0
                    }

                # Scale portion
                nutrition = nutrition_engine.scale_to_serving(food_info, serving_grams)
                exercises = DietaryAdvisor.get_activity_equivalents(nutrition["calories"])
                insights = DietaryAdvisor.get_dietary_insights(nutrition)

            # Identification Card
            st.success(f"### Identified: **{nutrition['name']}** ({confidence_pct}% Confidence)")
            st.caption(f"Category: {nutrition.get('category', 'Main Course')} | Model: EfficientNet-B0 Transfer Learning")

            # Nutri-Score & Tags
            score = nutrition.get("nutri_score", {"grade": "A", "verdict": "Nutritious"})
            st.info(f"**Nutri-Score Rating: Grade {score['grade']}** — {score['verdict']}")

            # Macronutrients 4 Columns
            m1, m2, m3, m4 = st.columns(4)
            m1.metric("Calories", f"{nutrition['calories']} kcal")
            m2.metric("Protein", f"{nutrition['protein_g']}g")
            m3.metric("Carbs", f"{nutrition['carbs_g']}g")
            m4.metric("Total Fat", f"{nutrition['fat_g']}g")

            # Micronutrients
            st.write("#### Micronutrients & RDA % Daily Values")
            c1, c2, c3 = st.columns(3)
            c1.write(f"🌾 **Fiber:** {nutrition['fiber_g']}g")
            c2.write(f"🧂 **Sodium:** {nutrition['sodium_mg']}mg")
            c3.write(f"🍬 **Sugars:** {nutrition['sugar_g']}g")

            # Exercise burn
            st.write("#### 🏃 Physical Activity to Burn Off")
            e1, e2, e3, e4 = st.columns(4)
            e1.write(f"🚶 **Walk:** {exercises['walking_minutes']}m")
            e2.write(f"🏃 **Jog:** {exercises['jogging_minutes']}m")
            e3.write(f"🚴 **Cycle:** {exercises['cycling_minutes']}m")
            e4.write(f"🏊 **Swim:** {exercises['swimming_minutes']}m")

            # Top-5 Predictions
            st.write("#### 🎯 Top-5 Deep Learning Predictions")
            top_df = pd.DataFrame([
                {"Food Name": k["display_name"], "Confidence (%)": k["confidence_percent"]}
                for k in prediction["top_k"]
            ])
            st.bar_chart(top_df.set_index("Food Name"))

            # Log to History Button
            meal_slot = st.selectbox("Meal Category", ["Breakfast", "Lunch", "Dinner", "Snack"])
            if st.button("💾 Log Meal to History Dashboard"):
                log_meal(
                    food_class=pred_class,
                    food_name=nutrition["name"],
                    serving_g=nutrition["serving_size_g"],
                    calories=nutrition["calories"],
                    protein_g=nutrition["protein_g"],
                    carbs_g=nutrition["carbs_g"],
                    fat_g=nutrition["fat_g"],
                    fiber_g=nutrition["fiber_g"],
                    sodium_mg=nutrition["sodium_mg"],
                    confidence=prediction["confidence"],
                    model_name="EfficientNet-B0",
                    meal_type=meal_slot
                )
                st.toast("Meal successfully logged to database!")
        else:
            st.info("Please upload an image, capture a photo, or choose a preset on the left.")

# VIEW 2: DASHBOARD
elif app_mode == "📈 Dietary History Dashboard":
    st.subheader("Dietary Analytics & Meal History")
    summary = get_today_summary()
    totals = summary["totals"]
    prog = summary["progress"]

    d1, d2, d3, d4 = st.columns(4)
    d1.metric("Today's Calories", f"{totals['total_calories']:.0f} kcal", f"{prog['remaining_calories']:.0f} kcal left")
    d2.metric("Protein", f"{totals['total_protein']:.1f}g", f"{prog['protein_pct']}% of 60g")
    d3.metric("Carbohydrates", f"{totals['total_carbs']:.1f}g", f"{prog['carbs_pct']}% of 250g")
    d4.metric("Total Fat", f"{totals['total_fat']:.1f}g", f"{prog['fat_pct']}% of 65g")

    st.write("### Logged Meal Records")
    history_records = get_history(limit=50)
    if history_records:
        df_hist = pd.DataFrame(history_records)
        df_display = df_hist[["logged_at", "meal_type", "food_name", "serving_g", "calories", "protein_g", "carbs_g", "fat_g", "confidence"]]
        st.dataframe(df_display, use_container_width=True)

        if st.button("🗑️ Clear History"):
            clear_history()
            st.experimental_rerun()
    else:
        st.write("No meals recorded yet. Log food items from the Scanner view.")

# VIEW 3: CATALOG
elif app_mode == "🥗 Food-101 Catalog":
    st.subheader("Food-101 Nutritional Database (101 Benchmark Classes)")
    foods = nutrition_engine.get_all_foods()
    search = st.text_input("Filter foods", "")
    filtered = [f for f in foods if search.lower() in f["name"].lower() or search.lower() in f["category"].lower()]
    df_cat = pd.DataFrame(filtered)[["name", "category", "serving_size_g", "calories", "protein_g", "carbs_g", "fat_g", "fiber_g", "health_score"]]
    st.dataframe(df_cat, use_container_width=True)

# VIEW 4: ARCHITECTURE
elif app_mode == "🧠 Architecture & Flow":
    st.subheader("System Architecture and Deep Learning Workflow")
    st.markdown("""
    ```
    Food Image (Camera / Upload)
           │
           ▼
    Image Preprocessing (Resize 224x224, ImageNet Normalization)
           │
           ▼
    Deep Learning Model (EfficientNet-B0 with Transfer Learning)
           │
           ▼
    Food Recognition (Softmax Top-K Classes & Confidence Scores)
           │
           ▼
    Food-101 Nutrition Lookup Module
           │
           ▼
    Nutrition Analysis (Calories, Macros, Micronutrients, Nutri-Score)
           │
           ▼
    Dietary Dashboard & History Tracking (SQLite Persistence)
    ```
    """)
