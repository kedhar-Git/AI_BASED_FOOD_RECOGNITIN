"""
Nutrition Module for AI-Based Food Recognition and Nutrition Analysis System
"""

from .engine import NutritionEngine
from .dietary_advisor import DietaryAdvisor

__all__ = ["NutritionEngine", "DietaryAdvisor"]
