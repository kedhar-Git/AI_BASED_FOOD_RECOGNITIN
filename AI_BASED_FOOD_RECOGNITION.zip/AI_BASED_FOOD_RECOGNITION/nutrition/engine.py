"""
Nutrition Engine for Food-101 Dataset
Provides nutrient lookups, serving scaling, RDA % calculations, and Nutri-Scores.
"""

import json
import os
from typing import Dict, Any, Optional, List

# Standard 2,000 kcal Daily Recommended Allowances (FDA & WHO)
RDA_REFERENCE = {
    "calories": 2000.0,    # kcal
    "protein_g": 50.0,     # g
    "carbs_g": 275.0,      # g
    "fat_g": 78.0,         # g
    "fiber_g": 28.0,       # g
    "sugar_g": 50.0,       # g (recommended max limit)
    "sodium_mg": 2300.0,   # mg (recommended max limit)
    "cholesterol_mg": 300.0, # mg (recommended max limit)
    "potassium_mg": 4700.0 # mg
}

class NutritionEngine:
    def __init__(self, data_path: Optional[str] = None):
        if data_path is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            data_path = os.path.join(base_dir, "data", "food101_nutrition.json")
            
        self.data_path = data_path
        self.nutrition_db: Dict[str, Dict[str, Any]] = {}
        self._load_database()
        
    def _load_database(self):
        if not os.path.exists(self.data_path):
            raise FileNotFoundError(f"Nutrition database not found at {self.data_path}")
            
        with open(self.data_path, "r", encoding="utf-8") as f:
            self.nutrition_db = json.load(f)
            
    def get_all_foods(self) -> List[Dict[str, Any]]:
        """Return list of all foods in the database."""
        result = []
        for class_id, info in self.nutrition_db.items():
            item = dict(info)
            item["class_id"] = class_id
            result.append(item)
        return result

    def lookup(self, query: str) -> Optional[Dict[str, Any]]:
        """
        Lookup nutritional info by class_id or human-readable name.
        Case-insensitive and handles underscores/hyphens/spaces.
        """
        norm_query = query.strip().lower().replace("-", "_").replace(" ", "_")
        
        # Direct key match
        if norm_query in self.nutrition_db:
            data = dict(self.nutrition_db[norm_query])
            data["class_id"] = norm_query
            return self._enrich_data(data)
            
        # Match by display name or partial name
        for class_id, info in self.nutrition_db.items():
            name_norm = info["name"].lower().replace("-", "_").replace(" ", "_")
            if norm_query == name_norm or norm_query in name_norm or name_norm in norm_query:
                data = dict(info)
                data["class_id"] = class_id
                return self._enrich_data(data)
                
        # Keyword matching
        for class_id, info in self.nutrition_db.items():
            words = norm_query.split("_")
            if any(w in class_id for w in words if len(w) > 3):
                data = dict(info)
                data["class_id"] = class_id
                return self._enrich_data(data)
                
        return None

    def scale_to_serving(self, food_data: Dict[str, Any], grams: float) -> Dict[str, Any]:
        """Scale nutritional metrics according to user-selected gram portion."""
        base_serving = float(food_data.get("serving_size_g", 100))
        ratio = max(0.1, grams / base_serving)
        
        scaled = dict(food_data)
        scaled["serving_size_g"] = round(grams, 1)
        scaled["calories"] = round(food_data["calories"] * ratio, 1)
        scaled["protein_g"] = round(food_data["protein_g"] * ratio, 1)
        scaled["carbs_g"] = round(food_data["carbs_g"] * ratio, 1)
        scaled["fat_g"] = round(food_data["fat_g"] * ratio, 1)
        scaled["fiber_g"] = round(food_data["fiber_g"] * ratio, 1)
        scaled["sugar_g"] = round(food_data.get("sugar_g", 0) * ratio, 1)
        scaled["sodium_mg"] = round(food_data.get("sodium_mg", 0) * ratio, 1)
        scaled["cholesterol_mg"] = round(food_data.get("cholesterol_mg", 0) * ratio, 1)
        scaled["potassium_mg"] = round(food_data.get("potassium_mg", 0) * ratio, 1)
        
        return self._enrich_data(scaled)

    def _enrich_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Compute RDA percentages, macronutrient calorie ratios, and health grade."""
        rda_pct = {}
        for nutrient, rda_val in RDA_REFERENCE.items():
            if nutrient in data and rda_val > 0:
                rda_pct[nutrient] = round((data[nutrient] / rda_val) * 100, 1)
        data["rda_percentages"] = rda_pct
        
        # Macro calories ratio (Carb: 4 kcal/g, Protein: 4 kcal/g, Fat: 9 kcal/g)
        p_cal = data["protein_g"] * 4.0
        c_cal = data["carbs_g"] * 4.0
        f_cal = data["fat_g"] * 9.0
        total_macro_cal = max(1.0, p_cal + c_cal + f_cal)
        
        data["macro_distribution"] = {
            "protein_percent": round((p_cal / total_macro_cal) * 100, 1),
            "carbs_percent": round((c_cal / total_macro_cal) * 100, 1),
            "fat_percent": round((f_cal / total_macro_cal) * 100, 1)
        }
        
        # Nutri-Score calculation
        score = data.get("health_score", 6.0)
        if score >= 8.5:
            grade = "A"
            color = "#10B981" # Emerald Green
            verdict = "Excellent Nutritional Quality"
        elif score >= 7.0:
            grade = "B"
            color = "#34D399" # Light Green
            verdict = "Good Nutritional Balance"
        elif score >= 5.5:
            grade = "C"
            color = "#FBBF24" # Amber
            verdict = "Moderate - Consume in Moderation"
        elif score >= 4.5:
            grade = "D"
            color = "#F97316" # Orange
            verdict = "Energy Dense - Limit Portion"
        else:
            grade = "E"
            color = "#EF4444" # Red
            verdict = "High Calorie / Indulgence Item"
            
        data["nutri_score"] = {
            "grade": grade,
            "color": color,
            "rating_10": score,
            "verdict": verdict
        }
        
        return data
