"""
Dietary Advisor Module
Generates actionable dietary recommendations, physical activity burn-off equivalents,
and metabolic suitability tips for identified foods.
"""

from typing import Dict, Any, List

class DietaryAdvisor:
    @staticmethod
    def get_activity_equivalents(calories: float) -> Dict[str, int]:
        """
        Estimate minutes of standard exercise required to burn off the food's calories
        (based on an average 70kg / 154 lb adult).
        - Brisk Walking: ~4.5 kcal / min
        - Jogging / Running: ~10 kcal / min
        - Cycling: ~7.5 kcal / min
        - Swimming: ~8 kcal / min
        """
        cal = max(1.0, float(calories))
        return {
            "walking_minutes": int(round(cal / 4.5)),
            "jogging_minutes": int(round(cal / 10.0)),
            "cycling_minutes": int(round(cal / 7.5)),
            "swimming_minutes": int(round(cal / 8.0))
        }

    @staticmethod
    def get_dietary_insights(food_data: Dict[str, Any]) -> List[Dict[str, str]]:
        """Generate smart dietary advice based on nutrient thresholds."""
        insights = []
        cals = food_data.get("calories", 0)
        protein = food_data.get("protein_g", 0)
        carbs = food_data.get("carbs_g", 0)
        fat = food_data.get("fat_g", 0)
        fiber = food_data.get("fiber_g", 0)
        sodium = food_data.get("sodium_mg", 0)
        sugar = food_data.get("sugar_g", 0)

        # Protein assessment
        if protein >= 25:
            insights.append({
                "type": "positive",
                "badge": "High Protein",
                "title": "Muscle Growth & Recovery Support",
                "message": f"Contains {protein}g of protein per serving, making it optimal for muscle protein synthesis and prolonged satiety."
            })
        elif protein < 5:
            insights.append({
                "type": "neutral",
                "badge": "Low Protein",
                "title": "Protein Supplementation Recommended",
                "message": "Low in protein. Consider pairing this with a lean protein source (e.g., grilled tofu, Greek yogurt, or eggs) for metabolic balance."
            })

        # Fiber assessment
        if fiber >= 5:
            insights.append({
                "type": "positive",
                "badge": "Fiber Rich",
                "title": "Gut Health & Glycemic Control",
                "message": f"Rich in dietary fiber ({fiber}g), helping stabilize blood sugar spikes, improve microbiome health, and aid digestion."
            })
        elif carbs > 40 and fiber < 2:
            insights.append({
                "type": "warning",
                "badge": "Refined Carbs",
                "title": "Potential Fast Glucose Spike",
                "message": "High simple carbohydrate content with low fiber may cause a rapid insulin spike followed by energy slump."
            })

        # Sodium assessment
        if sodium >= 800:
            insights.append({
                "type": "warning",
                "badge": "High Sodium",
                "title": "Blood Pressure Alert",
                "message": f"Contains {sodium}mg of sodium (~{round(sodium/2300*100)}% of daily recommended limit). Drink plenty of water and counterbalance with high-potassium foods."
            })
        elif sodium < 300:
            insights.append({
                "type": "positive",
                "badge": "Heart Friendly",
                "title": "Low Sodium Profile",
                "message": "Naturally low in sodium, promoting optimal cardiovascular health and fluid balance."
            })

        # Caloric density
        if cals > 500:
            insights.append({
                "type": "info",
                "badge": "Energy Dense",
                "title": "High Caloric Load",
                "message": f"Supplies {cals} kcal. Ideal as a main meal for active individuals, but portion control is recommended for weight management."
            })
        elif cals < 200:
            insights.append({
                "type": "positive",
                "badge": "Low Calorie",
                "title": "Calorie Deficit Friendly",
                "message": f"At just {cals} kcal, this is a light meal or guilt-free snack suitable for weight loss programs."
            })

        # Sugar assessment
        if sugar >= 20:
            insights.append({
                "type": "warning",
                "badge": "High Sugar",
                "title": "Elevated Sugar Content",
                "message": f"Contains {sugar}g of sugars. Recommended for occasional indulgence rather than daily staple."
            })

        return insights
