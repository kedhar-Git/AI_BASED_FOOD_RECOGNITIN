# PROJECT REPORT
## AI-Based Food Recognition and Nutrition Analysis System

**Project Members:**
1. **T. Kedhar** — URN: `24011CSEAI0050`
2. **S. Sindhu** — URN: `24011CSEAI0047`
3. **M. ManiDeepika** — URN: `24011CSEAI0138`

**Department:** Computer Science and Engineering (Artificial Intelligence)  
**Academic Year:** 2026

---

## Abstract

The **AI-Based Food Recognition and Nutrition Analysis System** is an intelligent application designed to help users easily understand the nutritional content of the food they consume. People often find it difficult and time-consuming to manually identify and calculate the calories, protein, carbohydrates, fats, fiber, and other nutritional values present in their meals. Existing food and nutrition applications may also require users to manually enter food items, which can be inconvenient and may lead to incorrect or incomplete information. To overcome these limitations, this project implements an automated end-to-end system that combines Artificial Intelligence, Deep Learning, and Computer Vision to recognize food directly from an image and provide its estimated nutritional information.

In this system, the user can either upload a food image or capture an image using a camera. The input image is first processed using image-processing techniques such as resizing and normalization to make it suitable for the Deep Learning model. A Transfer Learning model utilizing **EfficientNet-B0** is used to analyze the image and identify the food category. Transfer Learning allows the system to make use of visual representations learned from extensive datasets and adapt them specifically for fine-grained food recognition. The model produces the predicted food name along with a confidence score and Top-5 ranked alternatives.

Once the food item has been recognized, its name is passed to the nutrition lookup module. The predicted food name is matched with a nutrition dataset containing nutritional information for all 101 food categories in the **Food-101** dataset. The system retrieves and displays important nutritional values such as calories, protein, carbohydrates, fat, dietary fiber, sodium, and Nutri-Scores. Additionally, the system provides a user-friendly dashboard where users can view previously analyzed food items and maintain their food-analysis history, helping users review dietary patterns over time.

---

## 1. Introduction

### 1.1 Background
Diet-related chronic illnesses such as obesity, cardiovascular disease, hypertension, and type 2 diabetes represent major global healthcare challenges. Nutritional self-monitoring is one of the most effective behavioral strategies for maintaining a healthy lifestyle. However, conventional dietary tracking approaches require tedious manual searching, barcode scanning, or manual entry of portion weights. Studies indicate that manual logging leads to high user attrition rates and significant reporting errors.

Automated image-based food recognition leverages recent advancements in Computer Vision and Deep Convolutional Neural Networks (CNNs) to make nutritional analysis seamless, instantaneous, and objective.

### 1.2 Problem Statement
Developing an automated food recognition and nutrition analysis system introduces several technical hurdles:
1. **Intra-Class Variability**: Food items of the same category can appear completely different depending on cooking styles, sauces, and plating.
2. **Inter-Class Similarity**: Different food items may look remarkably similar (e.g., various soups, curries, or stews).
3. **Deformable Nature of Food**: Unlike rigid objects (e.g., vehicles, chairs), food items lack fixed geometric structures.
4. **Nutritional Disconnect**: Most computer vision models stop at visual classification without linking predictions to actionable macro- and micronutrient profiles or personal daily budgets.

### 1.3 Objectives
- Implement an automated Computer Vision pipeline to recognize food images captured via camera or uploaded as files.
- Employ Transfer Learning with **EfficientNet-B0** to classify food items across the 101 categories of the **Food-101** benchmark dataset.
- Provide ranked Top-5 prediction probabilities and confidence scores.
- Build a comprehensive nutritional database mapped 1-to-1 with Food-101 categories.
- Calculate Daily Recommended Allowance (RDA) percentages, exercise burn-off equivalents, and automated dietary insights.
- Provide a responsive dashboard with persistent SQLite history tracking, daily caloric budgets, and interactive charts.

---

## 2. System Architecture & Working Process

The overall working process of the system follows a linear pipeline:

$$\text{Food Image} \longrightarrow \text{Image Preprocessing} \longrightarrow \text{Deep Learning Model} \longrightarrow \text{Food Recognition} \longrightarrow \text{Nutrition Dataset} \longrightarrow \text{Nutrition Analysis} \longrightarrow \text{Dashboard/History}$$

```
   ┌──────────────────────────────────────────────────────────────┐
   │                  1. Image Acquisition                         │
   │           (File Upload / Live Camera Capture)                │
   └──────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
   ┌──────────────────────────────────────────────────────────────┐
   │                  2. Image Preprocessing                       │
   │         • Resize to 256x256, Center Crop to 224x224          │
   │         • Normalize using ImageNet mean & standard deviation │
   └──────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
   ┌──────────────────────────────────────────────────────────────┐
   │               3. Deep Learning Classification                │
   │           EfficientNet-B0 (Transfer Learning Backbone)       │
   │           Adaptive Head: Linear(1280, 512) -> SiLU -> 101    │
   └──────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
   ┌──────────────────────────────────────────────────────────────┐
   │           4. Softmax Confidence & Top-K Extraction           │
   │           P(class_i) = exp(z_i) / Σ exp(z_j)                 │
   │           Top-1 Class + Top-5 Ranked Probabilities           │
   └──────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
   ┌──────────────────────────────────────────────────────────────┐
   │                5. Food-101 Nutrition Lookup                  │
   │        Match class_id with verified nutritional database     │
   │        Scale metrics according to portion slider (25g-500g)  │
   └──────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
   ┌──────────────────────────────────────────────────────────────┐
   │                6. Clinical & Dietary Analysis                │
   │         • Macronutrients (Calories, Protein, Carbs, Fat)     │
   │         • Micronutrients (Fiber, Sodium, Sugars, Potassium)  │
   │         • RDA % Calculations (WHO / FDA 2,000 kcal standard) │
   │         • Nutri-Score (Grade A to E) & Activity Burn-Off     │
   └──────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
   ┌──────────────────────────────────────────────────────────────┐
   │                7. Dietary Dashboard & History                │
   │         • SQLite Database Persistence                        │
   │         • Daily Calorie Budget & Macro Doughnut Chart        │
   │         • 7-Day Intake Trend Bar Chart & History Table       │
   └──────────────────────────────────────────────────────────────┘
```

---

## 3. Dataset Description

### 3.1 Primary Image Dataset: Food-101
The **Food-101** dataset (`dansbecker/food-101`) is a well-established academic benchmark for fine-grained food recognition:
- **Total Images:** 101,000 real-world food photographs.
- **Number of Classes:** 101 distinct food categories.
- **Distribution:** 1,000 images per class (750 training images, 250 validation images).
- **Diversity:** Images originate from real-world online food communities, featuring diverse lighting conditions, backgrounds, angles, and dish presentations.

### 3.2 Food-101 Nutritional Information Dataset
To map visual classifications into nutritional profiles, a database was constructed containing complete nutritional data for every Food-101 category:
- **Standard Serving Size (g):** 60g to 420g depending on meal type.
- **Macronutrients:** Energy (kcal), Protein (g), Total Carbohydrates (g), Total Fats (g).
- **Micronutrients & Electrolytes:** Dietary Fiber (g), Free Sugars (g), Sodium (mg), Potassium (mg), Cholesterol (mg).
- **Qualitative Metadata:** Diet Category (Vegetarian, Vegan, Pescatarian, Non-Vegetarian), Common Allergens, Health Badges, and Descriptions.

---

## 4. Deep Learning Methodology & Transfer Learning

### 4.1 Why Transfer Learning with EfficientNet?
Training a deep neural network from scratch on 101,000 images requires substantial computational resources and carries a high risk of overfitting. Transfer Learning allows the model to utilize low-level visual features (edges, textures, gradients, color contrasts) learned from ImageNet-1K, fine-tuning only higher-level representation layers for food-specific features.

**EfficientNet-B0** utilizes **Compound Scaling**, balancing network depth ($d$), width ($w$), and input resolution ($r$) using a fixed compound coefficient $\phi$:

$$\text{Depth}: d = \alpha^\phi, \quad \text{Width}: w = \beta^\phi, \quad \text{Resolution}: r = \gamma^\phi$$

$$\text{subject to } \alpha \cdot \beta^2 \cdot \gamma^2 \approx 2, \quad \alpha \ge 1, \beta \ge 1, \gamma \ge 1$$

This architecture achieves superior Top-1 accuracy with only 5.3 million parameters, compared to ResNet-50 (25.6M parameters).

### 4.2 Network Architecture
- **Backbone:** Mobile Inverted Bottleneck Convolution (MBConv) stages with Squeeze-and-Excitation (SE) optimization.
- **Activation Function:** Swish / SiLU ($\text{SiLU}(x) = x \cdot \sigma(x)$).
- **Classification Head:**
  ```python
  nn.Sequential(
      nn.Dropout(p=0.3),
      nn.Linear(in_features=1280, out_features=512),
      nn.BatchNorm1d(num_features=512),
      nn.SiLU(),
      nn.Dropout(p=0.2),
      nn.Linear(in_features=512, out_features=101)
  )
  ```

### 4.3 Loss Function & Optimization
- **Loss:** Cross-Entropy Loss with Label Smoothing ($\epsilon = 0.1$):
  $$y_k^{\text{smooth}} = (1 - \epsilon) y_k + \frac{\epsilon}{K}$$
  Label smoothing prevents the network from becoming overconfident and improves generalization.
- **Optimizer:** AdamW with Weight Decay ($10^{-4}$) and initial learning rate $10^{-4}$.
- **Learning Rate Schedule:** Cosine Annealing scheduler decaying learning rate down to $10^{-6}$.

---

## 5. Nutritional Analysis & Dietary Dashboard Module

### 5.1 Dynamic Portion Scaling
Nutritional values are calculated based on user-selected portion weights ($W_{\text{user}}$) relative to reference serving weights ($W_{\text{ref}}$):

$$\text{Nutrient}_{\text{scaled}} = \text{Nutrient}_{\text{ref}} \times \left(\frac{W_{\text{user}}}{W_{\text{ref}}}\right)$$

### 5.2 Daily Recommended Allowance (RDA) Formula
Based on FDA and WHO standard 2,000 kcal reference diets:

$$\% \text{RDA} = \left(\frac{\text{Nutrient Content}}{\text{RDA Threshold}}\right) \times 100$$

- Energy: 2,000 kcal
- Protein: 50 g
- Carbohydrates: 275 g
- Total Fat: 78 g
- Dietary Fiber: 28 g
- Sodium Maximum: 2,300 mg

### 5.3 Physical Activity Burn-Off Estimation
Estimated minutes required for a 70 kg individual to expend the caloric load of the analyzed food:
- **Brisk Walking (4.5 kcal/min):** $T_{\text{walk}} = \text{Calories} / 4.5$
- **Running / Jogging (10.0 kcal/min):** $T_{\text{run}} = \text{Calories} / 10.0$
- **Cycling (7.5 kcal/min):** $T_{\text{cycle}} = \text{Calories} / 7.5$
- **Swimming (8.0 kcal/min):** $T_{\text{swim}} = \text{Calories} / 8.0$

---

## 6. Experimental Results & Verification

### 6.1 Inference & Recognition Results
The system was verified across diverse food categories:

| Input Image | Predicted Class | Model Confidence | Calories (kcal) | Protein (g) | Nutri-Score |
|---|---|---|---|---|---|
| Chicken Biryani / Curry | `chicken_curry` | **97.99%** | 480 kcal | 36.0 g | Grade B (8.1/10) |
| Artisan Pepperoni Pizza | `pizza` | **96.42%** | 480 kcal | 22.0 g | Grade C (6.2/10) |
| Caesar Salad with Parmesan | `caesar_salad` | **95.80%** | 260 kcal | 8.0 g | Grade B (7.1/10) |
| Fresh Salmon Sushi & Maki | `sushi` | **96.15%** | 310 kcal | 16.0 g | Grade A (8.6/10) |

### 6.2 System Performance
- **Inference Latency (CPU):** ~85 ms per image.
- **Pre-Processing Time:** ~12 ms per image.
- **Database Query Latency:** < 2 ms.
- **Client Render Time:** < 50 ms.

---

## 7. Conclusion & Future Work

### 7.1 Conclusion
The **AI-Based Food Recognition and Nutrition Analysis System** successfully demonstrates the integration of Computer Vision, Deep Learning (EfficientNet-B0 Transfer Learning), and automated nutritional science. By replacing manual dietary logging with real-time image recognition, the system provides users with immediate visibility into their caloric intake, macronutrient distribution, and micronutrient consumption. The interactive dashboard and SQLite database persistence enable long-term nutritional self-monitoring.

### 7.2 Future Scope
1. **Multi-Food Detection (Bounding Boxes):** Extending the system using YOLOv8 or Mask R-CNN to recognize and segment multiple food items on a single plate.
2. **Volumetric Portion Estimation:** Utilizing depth sensors or stereoscopic vision to estimate portion volumes (in milliliters/grams) directly from 3D camera geometry.
3. **Personalized Health Profiles:** Integrating diabetic, hypertensive, and renal dietary constraints to provide customized warnings for specific medical conditions.
4. **Mobile Deployment:** Exporting the trained model to ONNX / TensorFlow Lite for offline iOS and Android applications.

---

## 8. References
1. Bossard, L., Guillaumin, M., & Van Gool, L. (2014). *Food-101 – Mining Discriminative Components with Random Forests*. European Conference on Computer Vision (ECCV).
2. Tan, M., & Le, Q. V. (2019). *EfficientNet: Rethinking Model Scaling for Convolutional Neural Networks*. International Conference on Machine Learning (ICML).
3. He, K., Zhang, X., Ren, S., & Sun, J. (2016). *Deep Residual Learning for Image Recognition*. IEEE Conference on Computer Vision and Pattern Recognition (CVPR).
4. U.S. Department of Agriculture (USDA), Agricultural Research Service. *FoodData Central*, 2024.
5. World Health Organization (WHO). *Healthy Diet Guidelines & Daily Recommended Nutritional Intakes*, 2023.
