@echo off
title AI-Based Food Recognition & Nutrition Analysis System
cls
echo =====================================================================
echo    AI-BASED FOOD RECOGNITION AND NUTRITION ANALYSIS SYSTEM
echo    Authors: T. Kedhar, S. Sindhu, M. ManiDeepika
echo    Dataset: Food-101 Benchmark (dansbecker/food-101)
echo =====================================================================
echo.
echo Select Mode to Run:
echo   [1] Modern Web Application (FastAPI + Glassmorphic Dashboard) - Recommended
echo   [2] Academic Streamlit Dashboard (for Lab viva / thesis demo)
echo   [3] Train / Fine-Tune Deep Learning Model on Food-101
echo   [4] Exit
echo.
set /p mode="Enter choice (1/2/3/4): "

if "%mode%"=="1" (
    echo.
    echo Starting FastAPI Web Server at http://127.0.0.1:8000 ...
    start http://127.0.0.1:8000
    if exist C:\Users\kedha\food_env\Scripts\python.exe (
        C:\Users\kedha\food_env\Scripts\python.exe -m uvicorn backend.app:app --host 127.0.0.1 --port 8000 --reload
    ) else (
        python -m uvicorn backend.app:app --host 127.0.0.1 --port 8000 --reload
    )
) else if "%mode%"=="2" (
    echo.
    echo Starting Streamlit Presentation App at http://127.0.0.1:8501 ...
    if exist C:\Users\kedha\food_env\Scripts\python.exe (
        C:\Users\kedha\food_env\Scripts\python.exe -m streamlit run streamlit_app.py
    ) else (
        python -m streamlit run streamlit_app.py
    )
) else if "%mode%"=="3" (
    echo.
    echo Deep Learning Model Training Interface:
    echo Please make sure you have downloaded the Food-101 dataset from Kaggle:
    echo https://www.kaggle.com/datasets/dansbecker/food-101
    set /p datapath="Enter path to food-101 directory [default: ./data/food-101]: "
    if "%datapath%"=="" set datapath=./data/food-101
    if exist C:\Users\kedha\food_env\Scripts\python.exe (
        C:\Users\kedha\food_env\Scripts\python.exe -m model.train --data_dir "%datapath%" --model efficientnet_b0 --epochs 10
    ) else (
        python -m model.train --data_dir "%datapath%" --model efficientnet_b0 --epochs 10
    )
) else (
    echo Exiting...
)
pause
