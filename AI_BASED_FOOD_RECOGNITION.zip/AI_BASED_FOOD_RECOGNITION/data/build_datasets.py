"""
Script to generate verified, comprehensive Food-101 nutritional information dataset
mapped to all 101 official classes from the Food-101 benchmark dataset (dansbecker/food-101).
"""

import json
import os

CLASSES_101 = [
    "apple_pie", "baby_back_ribs", "baklava", "beef_carpaccio", "beef_tartare",
    "beet_salad", "beignets", "bibimbap", "bread_pudding", "breakfast_burrito",
    "bruschetta", "caesar_salad", "cannoli", "caprese_salad", "carrot_cake",
    "ceviche", "cheese_plate", "cheesecake", "chicken_curry", "chicken_quesadilla",
    "chicken_wings", "chocolate_cake", "chocolate_mousse", "churros", "clam_chowder",
    "club_sandwich", "crab_cakes", "creme_brulee", "croque_madame", "cup_cakes",
    "deviled_eggs", "donuts", "dumplings", "edamame", "eggs_benedict",
    "escargots", "falafel", "filet_mignon", "fish_and_chips", "foie_gras",
    "french_fries", "french_onion_soup", "french_toast", "fried_calamari", "fried_rice",
    "frozen_yogurt", "garlic_bread", "gnocchi", "greek_salad", "grilled_cheese_sandwich",
    "grilled_salmon", "guacamole", "gyoza", "hamburger", "hot_and_sour_soup",
    "hot_dog", "huevos_rancheros", "hummus", "ice_cream", "lasagna",
    "lobster_bisque", "lobster_roll_sandwich", "macaroni_and_cheese", "macarons", "miso_soup",
    "mussels", "nachos", "omelette", "onion_rings", "oysters",
    "pad_thai", "paella", "pancakes", "panna_cotta", "peking_duck",
    "pho", "pizza", "pork_chop", "poutine", "prime_rib",
    "pulled_pork_sandwich", "ramen", "ravioli", "red_velvet_cake", "risotto",
    "samosa", "sashimi", "scallops", "seaweed_salad", "shrimp_and_grits",
    "spaghetti_bolognese", "spaghetti_carbonara", "spring_rolls", "steak", "strawberry_shortcake",
    "sushi", "tacos", "takoyaki", "tiramisu", "tuna_tartare", "waffles"
]

# Nutritional profiles per standard single serving (USDA & Food-101 Nutritional Information dataset)
NUTRITION_PROFILES = {
    "apple_pie": {
        "name": "Apple Pie", "category": "Dessert", "serving_size_g": 130,
        "calories": 310, "protein_g": 3.0, "carbs_g": 43.0, "fat_g": 14.5, "fiber_g": 2.1,
        "sugar_g": 20.0, "sodium_mg": 250, "cholesterol_mg": 0, "potassium_mg": 115,
        "vitamins": "Vitamin C, Iron, Calcium", "health_score": 5.2, "diet_type": "Vegetarian",
        "health_tags": ["Sweet", "Comfort Food", "Carb Rich"], "allergens": ["Gluten", "Dairy"],
        "description": "Traditional baked pie with spiced sliced apple filling in a buttery flaky crust."
    },
    "baby_back_ribs": {
        "name": "Baby Back Ribs", "category": "Main Course", "serving_size_g": 250,
        "calories": 640, "protein_g": 42.0, "carbs_g": 12.0, "fat_g": 48.0, "fiber_g": 0.5,
        "sugar_g": 10.0, "sodium_mg": 890, "cholesterol_mg": 160, "potassium_mg": 520,
        "vitamins": "Iron, Zinc, Vitamin B12", "health_score": 4.8, "diet_type": "Non-Vegetarian",
        "health_tags": ["High Protein", "Savory", "Keto Friendly"], "allergens": ["None"],
        "description": "Tender pork loin ribs glazed in smoky barbecue sauce and slow cooked."
    },
    "baklava": {
        "name": "Baklava", "category": "Dessert", "serving_size_g": 75,
        "calories": 330, "protein_g": 5.0, "carbs_g": 38.0, "fat_g": 18.0, "fiber_g": 2.0,
        "sugar_g": 22.0, "sodium_mg": 110, "cholesterol_mg": 15, "potassium_mg": 130,
        "vitamins": "Magnesium, Vitamin E", "health_score": 4.2, "diet_type": "Vegetarian",
        "health_tags": ["Nut Rich", "Honey Sweetened"], "allergens": ["Gluten", "Dairy", "Tree Nuts"],
        "description": "Rich layered pastry made of filo pastry filled with chopped nuts and sweetened with syrup or honey."
    },
    "beef_carpaccio": {
        "name": "Beef Carpaccio", "category": "Appetizer", "serving_size_g": 120,
        "calories": 190, "protein_g": 24.0, "carbs_g": 1.5, "fat_g": 10.0, "fiber_g": 0.2,
        "sugar_g": 0.5, "sodium_mg": 420, "cholesterol_mg": 65, "potassium_mg": 380,
        "vitamins": "Iron, Vitamin B12, Zinc", "health_score": 7.8, "diet_type": "Non-Vegetarian",
        "health_tags": ["High Protein", "Low Carb", "Keto Friendly"], "allergens": ["Dairy"],
        "description": "Thinly sliced raw beef tenderloin drizzled with extra virgin olive oil, lemon, and shaved Parmesan."
    },
    "beef_tartare": {
        "name": "Beef Tartare", "category": "Appetizer", "serving_size_g": 150,
        "calories": 280, "protein_g": 30.0, "carbs_g": 2.5, "fat_g": 17.0, "fiber_g": 0.4,
        "sugar_g": 1.0, "sodium_mg": 480, "cholesterol_mg": 185, "potassium_mg": 410,
        "vitamins": "Vitamin A, Iron, Vitamin B12", "health_score": 7.2, "diet_type": "Non-Vegetarian",
        "health_tags": ["High Protein", "Keto Friendly"], "allergens": ["Eggs", "Mustard"],
        "description": "Finely chopped raw beef seasoned with capers, shallots, Dijon mustard, and topped with raw egg yolk."
    },
    "beet_salad": {
        "name": "Beet Salad", "category": "Salad", "serving_size_g": 180,
        "calories": 160, "protein_g": 4.5, "carbs_g": 16.0, "fat_g": 9.5, "fiber_g": 3.8,
        "sugar_g": 11.0, "sodium_mg": 310, "cholesterol_mg": 15, "potassium_mg": 440,
        "vitamins": "Folate, Vitamin C, Potassium", "health_score": 8.9, "diet_type": "Vegetarian",
        "health_tags": ["High Fiber", "Antioxidant Rich", "Heart Healthy"], "allergens": ["Dairy", "Tree Nuts"],
        "description": "Roasted beetroot salad tossed with goat cheese, arugula, walnuts, and balsamic reduction vinaigrette."
    },
    "beignets": {
        "name": "Beignets", "category": "Dessert", "serving_size_g": 90,
        "calories": 310, "protein_g": 5.0, "carbs_g": 42.0, "fat_g": 13.5, "fiber_g": 1.2,
        "sugar_g": 18.0, "sodium_mg": 240, "cholesterol_mg": 35, "potassium_mg": 85,
        "vitamins": "Calcium, Iron", "health_score": 4.0, "diet_type": "Vegetarian",
        "health_tags": ["Deep Fried", "Comfort Food"], "allergens": ["Gluten", "Dairy", "Eggs"],
        "description": "New Orleans style deep-fried choux choux pastry generously dusted with powdered sugar."
    },
    "bibimbap": {
        "name": "Bibimbap", "category": "Main Course", "serving_size_g": 350,
        "calories": 540, "protein_g": 26.0, "carbs_g": 72.0, "fat_g": 16.0, "fiber_g": 6.5,
        "sugar_g": 7.0, "sodium_mg": 780, "cholesterol_mg": 120, "potassium_mg": 680,
        "vitamins": "Vitamin A, Vitamin C, Iron", "health_score": 8.4, "diet_type": "Non-Vegetarian",
        "health_tags": ["Balanced Meal", "Nutrient Dense", "Fiber Rich"], "allergens": ["Eggs", "Soy", "Sesame"],
        "description": "Korean rice bowl topped with seasoned sautéed vegetables, marinated beef, gochujang chili paste, and fried egg."
    },
    "bread_pudding": {
        "name": "Bread Pudding", "category": "Dessert", "serving_size_g": 160,
        "calories": 370, "protein_g": 8.0, "carbs_g": 53.0, "fat_g": 14.5, "fiber_g": 1.5,
        "sugar_g": 31.0, "sodium_mg": 320, "cholesterol_mg": 85, "potassium_mg": 210,
        "vitamins": "Calcium, Vitamin A", "health_score": 4.5, "diet_type": "Vegetarian",
        "health_tags": ["Comfort Food", "Carb Rich"], "allergens": ["Gluten", "Dairy", "Eggs"],
        "description": "Baked dessert consisting of spiced bread soaked in vanilla egg custard and warm caramel sauce."
    },
    "breakfast_burrito": {
        "name": "Breakfast Burrito", "category": "Breakfast", "serving_size_g": 240,
        "calories": 490, "protein_g": 24.0, "carbs_g": 44.0, "fat_g": 24.0, "fiber_g": 4.0,
        "sugar_g": 3.0, "sodium_mg": 920, "cholesterol_mg": 245, "potassium_mg": 460,
        "vitamins": "Vitamin A, Iron, Calcium", "health_score": 6.8, "diet_type": "Non-Vegetarian",
        "health_tags": ["High Protein", "Energy Booster"], "allergens": ["Gluten", "Eggs", "Dairy"],
        "description": "Flour tortilla wrapped with fluffy scrambled eggs, cheese, black beans, salsa, and savory sausage."
    },
    "bruschetta": {
        "name": "Bruschetta", "category": "Appetizer", "serving_size_g": 110,
        "calories": 170, "protein_g": 4.0, "carbs_g": 22.0, "fat_g": 7.5, "fiber_g": 2.2,
        "sugar_g": 3.0, "sodium_mg": 280, "cholesterol_mg": 0, "potassium_mg": 220,
        "vitamins": "Vitamin C, Lycopene, Vitamin K", "health_score": 8.2, "diet_type": "Vegan",
        "health_tags": ["Heart Healthy", "Antioxidant Rich"], "allergens": ["Gluten"],
        "description": "Grilled Italian rustic bread rubbed with garlic and topped with ripe tomatoes, olive oil, and fresh basil."
    },
    "caesar_salad": {
        "name": "Caesar Salad", "category": "Salad", "serving_size_g": 190,
        "calories": 260, "protein_g": 8.0, "carbs_g": 11.0, "fat_g": 21.0, "fiber_g": 3.0,
        "sugar_g": 2.5, "sodium_mg": 570, "cholesterol_mg": 30, "potassium_mg": 310,
        "vitamins": "Vitamin A, Vitamin K, Folate", "health_score": 7.1, "diet_type": "Non-Vegetarian",
        "health_tags": ["Low Carb", "Fresh Greens"], "allergens": ["Dairy", "Fish", "Gluten", "Eggs"],
        "description": "Crisp romaine lettuce tossed with creamy Caesar dressing, garlic herb croutons, and shaved Parmesan."
    },
    "cannoli": {
        "name": "Cannoli", "category": "Dessert", "serving_size_g": 85,
        "calories": 290, "protein_g": 6.0, "carbs_g": 32.0, "fat_g": 15.5, "fiber_g": 1.0,
        "sugar_g": 18.0, "sodium_mg": 180, "cholesterol_mg": 35, "potassium_mg": 125,
        "vitamins": "Calcium, Vitamin A", "health_score": 4.5, "diet_type": "Vegetarian",
        "health_tags": ["Sweet", "Crispy Pastry"], "allergens": ["Gluten", "Dairy", "Eggs"],
        "description": "Crispy fried Italian pastry tube filled with sweet creamy ricotta, chocolate chips, and orange zest."
    },
    "caprese_salad": {
        "name": "Caprese Salad", "category": "Salad", "serving_size_g": 160,
        "calories": 230, "protein_g": 12.0, "carbs_g": 6.0, "fat_g": 18.0, "fiber_g": 1.5,
        "sugar_g": 4.0, "sodium_mg": 340, "cholesterol_mg": 35, "potassium_mg": 280,
        "vitamins": "Calcium, Lycopene, Vitamin K", "health_score": 8.5, "diet_type": "Vegetarian",
        "health_tags": ["Keto Friendly", "Mediterranean Diet", "Fresh"], "allergens": ["Dairy"],
        "description": "Italian salad composed of fresh sliced mozzarella, heirloom tomatoes, fresh sweet basil, and extra virgin olive oil."
    },
    "carrot_cake": {
        "name": "Carrot Cake", "category": "Dessert", "serving_size_g": 120,
        "calories": 420, "protein_g": 4.5, "carbs_g": 54.0, "fat_g": 22.0, "fiber_g": 2.0,
        "sugar_g": 38.0, "sodium_mg": 350, "cholesterol_mg": 45, "potassium_mg": 190,
        "vitamins": "Vitamin A, Calcium", "health_score": 4.3, "diet_type": "Vegetarian",
        "health_tags": ["Spiced", "Comfort Food"], "allergens": ["Gluten", "Dairy", "Eggs", "Tree Nuts"],
        "description": "Moist spiced sponge cake packed with grated carrots, toasted walnuts, and layered with tangy cream cheese frosting."
    },
    "ceviche": {
        "name": "Ceviche", "category": "Appetizer", "serving_size_g": 170,
        "calories": 165, "protein_g": 24.0, "carbs_g": 7.0, "fat_g": 3.5, "fiber_g": 1.8,
        "sugar_g": 2.5, "sodium_mg": 410, "cholesterol_mg": 55, "potassium_mg": 490,
        "vitamins": "Vitamin C, Vitamin B12, Magnesium", "health_score": 9.2, "diet_type": "Pescatarian",
        "health_tags": ["High Protein", "Low Fat", "Heart Healthy", "Gluten Free"], "allergens": ["Fish", "Shellfish"],
        "description": "Fresh white fish cured in freshly squeezed citrus juice, cilantro, red onion, avocado, and chili peppers."
    },
    "cheese_plate": {
        "name": "Cheese Plate", "category": "Appetizer", "serving_size_g": 140,
        "calories": 460, "protein_g": 28.0, "carbs_g": 6.0, "fat_g": 37.0, "fiber_g": 0.5,
        "sugar_g": 2.0, "sodium_mg": 790, "cholesterol_mg": 105, "potassium_mg": 170,
        "vitamins": "Calcium, Vitamin B12, Zinc", "health_score": 6.2, "diet_type": "Vegetarian",
        "health_tags": ["High Protein", "Keto Friendly", "Calcium Rich"], "allergens": ["Dairy"],
        "description": "Artisanal platter of aged cheddar, creamy brie, gouda, and gorgonzola served with grapes and crackers."
    },
    "cheesecake": {
        "name": "Cheesecake", "category": "Dessert", "serving_size_g": 130,
        "calories": 410, "protein_g": 7.0, "carbs_g": 38.0, "fat_g": 26.0, "fiber_g": 0.8,
        "sugar_g": 28.0, "sodium_mg": 310, "cholesterol_mg": 95, "potassium_mg": 140,
        "vitamins": "Calcium, Vitamin A", "health_score": 4.1, "diet_type": "Vegetarian",
        "health_tags": ["Creamy", "Indulgent"], "allergens": ["Gluten", "Dairy", "Eggs"],
        "description": "Rich New York style cream cheese filling baked over a buttery graham cracker crumb crust."
    },
    "chicken_curry": {
        "name": "Chicken Curry / Biryani", "category": "Main Course", "serving_size_g": 320,
        "calories": 480, "protein_g": 36.0, "carbs_g": 32.0, "fat_g": 22.0, "fiber_g": 4.2,
        "sugar_g": 4.5, "sodium_mg": 740, "cholesterol_mg": 95, "potassium_mg": 590,
        "vitamins": "Iron, Vitamin B6, Niacin, Curcumin", "health_score": 8.1, "diet_type": "Non-Vegetarian",
        "health_tags": ["High Protein", "Antioxidant Rich", "Balanced"], "allergens": ["Dairy"],
        "description": "Tender chicken simmered in aromatic gravy of turmeric, cumin, coriander, ginger, garlic, and fragrant basmati."
    },
    "chicken_quesadilla": {
        "name": "Chicken Quesadilla", "category": "Main Course", "serving_size_g": 220,
        "calories": 510, "protein_g": 32.0, "carbs_g": 38.0, "fat_g": 26.0, "fiber_g": 3.0,
        "sugar_g": 2.5, "sodium_mg": 860, "cholesterol_mg": 85, "potassium_mg": 380,
        "vitamins": "Calcium, Vitamin B12, Iron", "health_score": 6.7, "diet_type": "Non-Vegetarian",
        "health_tags": ["High Protein", "Savory"], "allergens": ["Gluten", "Dairy"],
        "description": "Toasted flour tortilla stuffed with spiced grilled chicken breast, melted Monterrey Jack, and peppers."
    },
    "chicken_wings": {
        "name": "Chicken Wings", "category": "Appetizer", "serving_size_g": 200,
        "calories": 520, "protein_g": 38.0, "carbs_g": 6.0, "fat_g": 38.0, "fiber_g": 0.5,
        "sugar_g": 3.0, "sodium_mg": 980, "cholesterol_mg": 160, "potassium_mg": 340,
        "vitamins": "Niacin, Vitamin B6, Iron", "health_score": 5.4, "diet_type": "Non-Vegetarian",
        "health_tags": ["High Protein", "Keto Friendly"], "allergens": ["None"],
        "description": "Crispy fried chicken wings tossed in tangy buffalo hot sauce and served with celery sticks."
    },
    "chocolate_cake": {
        "name": "Chocolate Cake", "category": "Dessert", "serving_size_g": 125,
        "calories": 440, "protein_g": 5.5, "carbs_g": 58.0, "fat_g": 22.0, "fiber_g": 3.0,
        "sugar_g": 42.0, "sodium_mg": 320, "cholesterol_mg": 50, "potassium_mg": 240,
        "vitamins": "Iron, Magnesium", "health_score": 4.0, "diet_type": "Vegetarian",
        "health_tags": ["Indulgent", "Chocolate Lover"], "allergens": ["Gluten", "Dairy", "Eggs"],
        "description": "Decadent multi-layer chocolate sponge cake frosted with dark Dutch cocoa fudge ganache."
    },
    "chocolate_mousse": {
        "name": "Chocolate Mousse", "category": "Dessert", "serving_size_g": 110,
        "calories": 310, "protein_g": 5.0, "carbs_g": 26.0, "fat_g": 21.0, "fiber_g": 2.0,
        "sugar_g": 22.0, "sodium_mg": 85, "cholesterol_mg": 90, "potassium_mg": 220,
        "vitamins": "Iron, Calcium", "health_score": 4.8, "diet_type": "Vegetarian",
        "health_tags": ["Airy", "Rich Cocoa"], "allergens": ["Dairy", "Eggs"],
        "description": "Silky French whipped dessert made with dark chocolate, egg whites, and heavy cream."
    },
    "churros": {
        "name": "Churros", "category": "Dessert", "serving_size_g": 100,
        "calories": 370, "protein_g": 4.0, "carbs_g": 46.0, "fat_g": 19.0, "fiber_g": 1.8,
        "sugar_g": 16.0, "sodium_mg": 260, "cholesterol_mg": 20, "potassium_mg": 95,
        "vitamins": "Iron, Calcium", "health_score": 4.1, "diet_type": "Vegetarian",
        "health_tags": ["Crispy", "Cinnamon Sugar"], "allergens": ["Gluten", "Dairy", "Eggs"],
        "description": "Deep-fried ridged pastry dough dusted with fragrant cinnamon sugar and served with dipping chocolate."
    },
    "clam_chowder": {
        "name": "Clam Chowder", "category": "Soup", "serving_size_g": 240,
        "calories": 250, "protein_g": 11.0, "carbs_g": 21.0, "fat_g": 14.0, "fiber_g": 1.5,
        "sugar_g": 3.0, "sodium_mg": 840, "cholesterol_mg": 45, "potassium_mg": 380,
        "vitamins": "Vitamin B12, Iron, Selenium", "health_score": 6.9, "diet_type": "Pescatarian",
        "health_tags": ["Creamy Soup", "High B12"], "allergens": ["Shellfish", "Dairy", "Gluten"],
        "description": "Hearty New England soup loaded with tender clams, diced potatoes, celery, onions, and rich cream."
    },
    "club_sandwich": {
        "name": "Club Sandwich", "category": "Main Course", "serving_size_g": 280,
        "calories": 590, "protein_g": 34.0, "carbs_g": 48.0, "fat_g": 29.0, "fiber_g": 3.5,
        "sugar_g": 4.0, "sodium_mg": 1180, "cholesterol_mg": 85, "potassium_mg": 510,
        "vitamins": "Iron, Vitamin B3, Calcium", "health_score": 6.3, "diet_type": "Non-Vegetarian",
        "health_tags": ["High Protein", "Filling"], "allergens": ["Gluten", "Eggs", "Dairy"],
        "description": "Triple-decker toasted sandwich layered with sliced turkey, crispy bacon, lettuce, tomato, and mayo."
    },
    "crab_cakes": {
        "name": "Crab Cakes", "category": "Appetizer", "serving_size_g": 160,
        "calories": 310, "protein_g": 24.0, "carbs_g": 14.0, "fat_g": 18.0, "fiber_g": 1.0,
        "sugar_g": 1.5, "sodium_mg": 680, "cholesterol_mg": 110, "potassium_mg": 340,
        "vitamins": "Zinc, Vitamin B12, Selenium", "health_score": 7.4, "diet_type": "Pescatarian",
        "health_tags": ["High Protein", "Seafood"], "allergens": ["Shellfish", "Gluten", "Eggs"],
        "description": "Lump blue crab meat patties bound with light seasoning, pan seared until golden, served with remoulade."
    },
    "creme_brulee": {
        "name": "Creme Brulee", "category": "Dessert", "serving_size_g": 130,
        "calories": 360, "protein_g": 5.0, "carbs_g": 31.0, "fat_g": 24.0, "fiber_g": 0.0,
        "sugar_g": 28.0, "sodium_mg": 70, "cholesterol_mg": 165, "potassium_mg": 130,
        "vitamins": "Vitamin A, Calcium", "health_score": 4.4, "diet_type": "Vegetarian",
        "health_tags": ["Custard", "Torched Sugar"], "allergens": ["Dairy", "Eggs"],
        "description": "Rich vanilla custard base crowned with a contrasting layer of hardened caramelized sugar glass."
    },
    "croque_madame": {
        "name": "Croque Madame", "category": "Main Course", "serving_size_g": 230,
        "calories": 570, "protein_g": 31.0, "carbs_g": 36.0, "fat_g": 34.0, "fiber_g": 2.0,
        "sugar_g": 4.5, "sodium_mg": 1150, "cholesterol_mg": 210, "potassium_mg": 410,
        "vitamins": "Calcium, Vitamin A, Iron", "health_score": 5.7, "diet_type": "Non-Vegetarian",
        "health_tags": ["High Protein", "French Classic"], "allergens": ["Gluten", "Dairy", "Eggs"],
        "description": "Grilled ham and Gruyère sandwich smothered in béchamel sauce and topped with a fried sunny-side-up egg."
    },
    "cup_cakes": {
        "name": "Cupcakes", "category": "Dessert", "serving_size_g": 80,
        "calories": 290, "protein_g": 3.0, "carbs_g": 41.0, "fat_g": 13.0, "fiber_g": 0.8,
        "sugar_g": 28.0, "sodium_mg": 190, "cholesterol_mg": 35, "potassium_mg": 80,
        "vitamins": "Calcium, Iron", "health_score": 3.9, "diet_type": "Vegetarian",
        "health_tags": ["Sweet", "Party Treat"], "allergens": ["Gluten", "Dairy", "Eggs"],
        "description": "Individual baked sponge cake decorated with swirl of sweet vanilla buttercream frosting and sprinkles."
    },
    "deviled_eggs": {
        "name": "Deviled Eggs", "category": "Appetizer", "serving_size_g": 120,
        "calories": 220, "protein_g": 13.0, "carbs_g": 2.0, "fat_g": 18.0, "fiber_g": 0.3,
        "sugar_g": 1.2, "sodium_mg": 380, "cholesterol_mg": 380, "potassium_mg": 150,
        "vitamins": "Choline, Vitamin D, Vitamin A", "health_score": 7.3, "diet_type": "Vegetarian",
        "health_tags": ["High Protein", "Low Carb", "Keto Friendly"], "allergens": ["Eggs", "Mustard"],
        "description": "Hard-boiled egg whites filled with seasoned whipped yolk paste blended with mayonnaise and paprika."
    },
    "donuts": {
        "name": "Donuts", "category": "Dessert", "serving_size_g": 85,
        "calories": 340, "protein_g": 4.5, "carbs_g": 43.0, "fat_g": 17.0, "fiber_g": 1.2,
        "sugar_g": 22.0, "sodium_mg": 280, "cholesterol_mg": 25, "potassium_mg": 90,
        "vitamins": "Iron, Calcium", "health_score": 3.8, "diet_type": "Vegetarian",
        "health_tags": ["Deep Fried", "Glazed"], "allergens": ["Gluten", "Dairy", "Eggs"],
        "description": "Ring-shaped fried dough covered with sweet sugar glaze or chocolate icing."
    },
    "dumplings": {
        "name": "Dumplings / Dim Sum", "category": "Appetizer", "serving_size_g": 180,
        "calories": 320, "protein_g": 16.0, "carbs_g": 38.0, "fat_g": 12.0, "fiber_g": 2.2,
        "sugar_g": 2.0, "sodium_mg": 680, "cholesterol_mg": 45, "potassium_mg": 260,
        "vitamins": "Iron, Niacin", "health_score": 7.3, "diet_type": "Non-Vegetarian",
        "health_tags": ["Steamed / Pan Fried", "Savory"], "allergens": ["Gluten", "Soy", "Sesame"],
        "description": "Tender dough parcels filled with seasoned minced pork, scallions, cabbage, and ginger."
    },
    "edamame": {
        "name": "Edamame", "category": "Appetizer", "serving_size_g": 150,
        "calories": 180, "protein_g": 17.0, "carbs_g": 14.0, "fat_g": 8.0, "fiber_g": 8.0,
        "sugar_g": 3.0, "sodium_mg": 290, "cholesterol_mg": 0, "potassium_mg": 640,
        "vitamins": "Folate, Vitamin K, Iron, Magnesium", "health_score": 9.5, "diet_type": "Vegan",
        "health_tags": ["Plant Protein", "High Fiber", "Superfood", "Heart Healthy"], "allergens": ["Soy"],
        "description": "Steamed young whole soybean pods lightly dusted with coarse sea salt."
    },
    "eggs_benedict": {
        "name": "Eggs Benedict", "category": "Breakfast", "serving_size_g": 210,
        "calories": 520, "protein_g": 22.0, "carbs_g": 25.0, "fat_g": 38.0, "fiber_g": 1.2,
        "sugar_g": 2.5, "sodium_mg": 960, "cholesterol_mg": 395, "potassium_mg": 310,
        "vitamins": "Vitamin A, Choline, Iron", "health_score": 6.1, "diet_type": "Non-Vegetarian",
        "health_tags": ["High Protein", "Brunch Classic"], "allergens": ["Gluten", "Eggs", "Dairy"],
        "description": "Poached eggs and Canadian bacon served atop toasted English muffin halves, smothered in hollandaise sauce."
    },
    "escargots": {
        "name": "Escargots", "category": "Appetizer", "serving_size_g": 130,
        "calories": 210, "protein_g": 16.0, "carbs_g": 4.0, "fat_g": 15.0, "fiber_g": 0.2,
        "sugar_g": 0.5, "sodium_mg": 460, "cholesterol_mg": 70, "potassium_mg": 380,
        "vitamins": "Magnesium, Iron, Vitamin E", "health_score": 7.0, "diet_type": "Non-Vegetarian",
        "health_tags": ["French Delicacy", "Garlic Butter", "Keto Friendly"], "allergens": ["Dairy", "Mollusks"],
        "description": "Cooked land snails baked in shells with copious garlic, fresh parsley, and shallot herb butter."
    },
    "falafel": {
        "name": "Falafel", "category": "Appetizer", "serving_size_g": 150,
        "calories": 330, "protein_g": 13.0, "carbs_g": 32.0, "fat_g": 18.0, "fiber_g": 7.5,
        "sugar_g": 2.5, "sodium_mg": 420, "cholesterol_mg": 0, "potassium_mg": 460,
        "vitamins": "Folate, Iron, Magnesium", "health_score": 8.2, "diet_type": "Vegan",
        "health_tags": ["Plant Protein", "High Fiber", "Middle Eastern"], "allergens": ["Sesame"],
        "description": "Crisp fried spiced patties made from ground chickpeas, fresh parsley, cumin, and coriander."
    },
    "filet_mignon": {
        "name": "Filet Mignon", "category": "Main Course", "serving_size_g": 220,
        "calories": 480, "protein_g": 46.0, "carbs_g": 0.0, "fat_g": 32.0, "fiber_g": 0.0,
        "sugar_g": 0.0, "sodium_mg": 280, "cholesterol_mg": 150, "potassium_mg": 680,
        "vitamins": "Iron, Zinc, Vitamin B12", "health_score": 7.9, "diet_type": "Non-Vegetarian",
        "health_tags": ["High Protein", "Zero Carb", "Keto"], "allergens": ["None"],
        "description": "Pan-seared tenderloin steak cooked medium rare, tender and succulent."
    },
    "fish_and_chips": {
        "name": "Fish and Chips", "category": "Main Course", "serving_size_g": 320,
        "calories": 680, "protein_g": 32.0, "carbs_g": 62.0, "fat_g": 34.0, "fiber_g": 4.5,
        "sugar_g": 2.0, "sodium_mg": 890, "cholesterol_mg": 75, "potassium_mg": 740,
        "vitamins": "Vitamin B6, Iodine, Selenium", "health_score": 5.8, "diet_type": "Pescatarian",
        "health_tags": ["Crispy", "British Classic", "Filling"], "allergens": ["Fish", "Gluten"],
        "description": "Beer-battered deep fried cod fillet served alongside thick-cut chips and tartare sauce."
    },
    "foie_gras": {
        "name": "Foie Gras", "category": "Appetizer", "serving_size_g": 80,
        "calories": 370, "protein_g": 9.0, "carbs_g": 3.0, "fat_g": 36.0, "fiber_g": 0.0,
        "sugar_g": 1.0, "sodium_mg": 380, "cholesterol_mg": 195, "potassium_mg": 160,
        "vitamins": "Vitamin A, Vitamin B12, Iron", "health_score": 5.1, "diet_type": "Non-Vegetarian",
        "health_tags": ["High Fat", "French Gourmet"], "allergens": ["None"],
        "description": "Seared duck liver pate prized for rich buttery texture and delicate savory finish."
    },
    "french_fries": {
        "name": "French Fries", "category": "Fast Food", "serving_size_g": 140,
        "calories": 365, "protein_g": 4.0, "carbs_g": 48.0, "fat_g": 17.0, "fiber_g": 4.5,
        "sugar_g": 0.5, "sodium_mg": 340, "cholesterol_mg": 0, "potassium_mg": 580,
        "vitamins": "Potassium, Vitamin C, Vitamin B6", "health_score": 5.1, "diet_type": "Vegan",
        "health_tags": ["Crispy", "Popular Snack"], "allergens": ["None"],
        "description": "Crispy golden potato batons fried in oil and seasoned with fine sea salt."
    },
    "french_onion_soup": {
        "name": "French Onion Soup", "category": "Soup", "serving_size_g": 260,
        "calories": 240, "protein_g": 12.0, "carbs_g": 22.0, "fat_g": 12.0, "fiber_g": 2.8,
        "sugar_g": 7.0, "sodium_mg": 920, "cholesterol_mg": 35, "potassium_mg": 320,
        "vitamins": "Calcium, Iron", "health_score": 7.0, "diet_type": "Non-Vegetarian",
        "health_tags": ["Comfort Food", "Savory Broth"], "allergens": ["Gluten", "Dairy"],
        "description": "Caramelized onions simmered in rich beef broth, topped with crouton and bubbling Gruyère cheese."
    },
    "french_toast": {
        "name": "French Toast", "category": "Breakfast", "serving_size_g": 160,
        "calories": 380, "protein_g": 10.0, "carbs_g": 46.0, "fat_g": 17.0, "fiber_g": 2.0,
        "sugar_g": 18.0, "sodium_mg": 460, "cholesterol_mg": 145, "potassium_mg": 190,
        "vitamins": "Calcium, Vitamin A, Iron", "health_score": 5.5, "diet_type": "Vegetarian",
        "health_tags": ["Brunch", "Sweet & Savory"], "allergens": ["Gluten", "Dairy", "Eggs"],
        "description": "Brioche bread dipped in egg and milk mixture, pan-fried and topped with maple syrup."
    },
    "fried_calamari": {
        "name": "Fried Calamari", "category": "Appetizer", "serving_size_g": 160,
        "calories": 340, "protein_g": 22.0, "carbs_g": 24.0, "fat_g": 18.0, "fiber_g": 1.0,
        "sugar_g": 1.0, "sodium_mg": 560, "cholesterol_mg": 210, "potassium_mg": 310,
        "vitamins": "Copper, Zinc, Vitamin B12", "health_score": 6.8, "diet_type": "Pescatarian",
        "health_tags": ["High Protein", "Crispy Seafood"], "allergens": ["Mollusks", "Gluten"],
        "description": "Tender squid rings dusted with flour, deep-fried until crunchy, served with lemon wedges and marinara."
    },
    "fried_rice": {
        "name": "Fried Rice", "category": "Main Course", "serving_size_g": 280,
        "calories": 420, "protein_g": 14.0, "carbs_g": 62.0, "fat_g": 13.0, "fiber_g": 3.2,
        "sugar_g": 2.5, "sodium_mg": 780, "cholesterol_mg": 95, "potassium_mg": 280,
        "vitamins": "Iron, Vitamin B1", "health_score": 6.9, "diet_type": "Non-Vegetarian",
        "health_tags": ["Wok Hei", "Carb Fuel"], "allergens": ["Eggs", "Soy", "Sesame"],
        "description": "Wok-fried Jasmine rice with eggs, peas, carrots, scallions, and savory soy sauce."
    },
    "frozen_yogurt": {
        "name": "Frozen Yogurt", "category": "Dessert", "serving_size_g": 140,
        "calories": 180, "protein_g": 6.0, "carbs_g": 34.0, "fat_g": 3.0, "fiber_g": 0.5,
        "sugar_g": 26.0, "sodium_mg": 90, "cholesterol_mg": 12, "potassium_mg": 240,
        "vitamins": "Calcium, Probiotics", "health_score": 7.0, "diet_type": "Vegetarian",
        "health_tags": ["Low Fat", "Probiotic Rich", "Refreshing"], "allergens": ["Dairy"],
        "description": "Creamy churned frozen yogurt with active probiotic cultures and subtle tartness."
    },
    "garlic_bread": {
        "name": "Garlic Bread", "category": "Appetizer", "serving_size_g": 90,
        "calories": 240, "protein_g": 5.0, "carbs_g": 28.0, "fat_g": 12.0, "fiber_g": 1.8,
        "sugar_g": 2.0, "sodium_mg": 380, "cholesterol_mg": 20, "potassium_mg": 90,
        "vitamins": "Iron, Calcium", "health_score": 5.3, "diet_type": "Vegetarian",
        "health_tags": ["Garlic Butter", "Crispy"], "allergens": ["Gluten", "Dairy"],
        "description": "Crusty baguette toasted with garlic-infused herb butter and melted mozzarella."
    },
    "gnocchi": {
        "name": "Gnocchi", "category": "Main Course", "serving_size_g": 210,
        "calories": 360, "protein_g": 8.0, "carbs_g": 62.0, "fat_g": 9.0, "fiber_g": 3.5,
        "sugar_g": 3.0, "sodium_mg": 520, "cholesterol_mg": 25, "potassium_mg": 380,
        "vitamins": "Potassium, Iron", "health_score": 6.5, "diet_type": "Vegetarian",
        "health_tags": ["Italian Classic", "Carb Energy"], "allergens": ["Gluten", "Dairy", "Eggs"],
        "description": "Pillowy potato dumplings boiled and tossed in tomato basil or sage brown butter sauce."
    },
    "greek_salad": {
        "name": "Greek Salad", "category": "Salad", "serving_size_g": 220,
        "calories": 210, "protein_g": 6.0, "carbs_g": 12.0, "fat_g": 16.0, "fiber_g": 4.0,
        "sugar_g": 5.0, "sodium_mg": 680, "cholesterol_mg": 25, "potassium_mg": 420,
        "vitamins": "Vitamin C, Vitamin A, Calcium, Lycopene", "health_score": 8.8, "diet_type": "Vegetarian",
        "health_tags": ["Mediterranean", "Heart Healthy", "High Fiber"], "allergens": ["Dairy"],
        "description": "Crisp cucumbers, vine tomatoes, red onion, Kalamata olives, and block of Greek feta cheese dressed in oregano oil."
    },
    "grilled_cheese_sandwich": {
        "name": "Grilled Cheese Sandwich", "category": "Fast Food", "serving_size_g": 150,
        "calories": 420, "protein_g": 16.0, "carbs_g": 34.0, "fat_g": 24.0, "fiber_g": 2.0,
        "sugar_g": 3.5, "sodium_mg": 840, "cholesterol_mg": 60, "potassium_mg": 160,
        "vitamins": "Calcium, Vitamin A", "health_score": 5.4, "diet_type": "Vegetarian",
        "health_tags": ["Comfort Food", "Gooey Cheese"], "allergens": ["Gluten", "Dairy"],
        "description": "Pan-toasted sourdough bread with golden buttery crust and melted cheddar inside."
    },
    "grilled_salmon": {
        "name": "Grilled Salmon", "category": "Main Course", "serving_size_g": 200,
        "calories": 390, "protein_g": 40.0, "carbs_g": 0.0, "fat_g": 24.0, "fiber_g": 0.0,
        "sugar_g": 0.0, "sodium_mg": 260, "cholesterol_mg": 110, "potassium_mg": 720,
        "vitamins": "Omega-3 Fatty Acids, Vitamin D, Vitamin B12", "health_score": 9.6, "diet_type": "Pescatarian",
        "health_tags": ["Superfood", "High Protein", "Omega 3 Rich", "Zero Carb"], "allergens": ["Fish"],
        "description": "Atlantic salmon fillet char-grilled with olive oil, lemon zest, and dill herb butter."
    },
    "guacamole": {
        "name": "Guacamole", "category": "Appetizer", "serving_size_g": 120,
        "calories": 190, "protein_g": 2.5, "carbs_g": 11.0, "fat_g": 17.0, "fiber_g": 7.5,
        "sugar_g": 1.5, "sodium_mg": 210, "cholesterol_mg": 0, "potassium_mg": 580,
        "vitamins": "Potassium, Vitamin E, Folate", "health_score": 9.1, "diet_type": "Vegan",
        "health_tags": ["Healthy Fats", "High Fiber", "Heart Healthy"], "allergens": ["None"],
        "description": "Fresh mashed Hass avocados folded with lime juice, cilantro, diced tomatoes, and jalapenos."
    },
    "gyoza": {
        "name": "Gyoza", "category": "Appetizer", "serving_size_g": 150,
        "calories": 270, "protein_g": 14.0, "carbs_g": 28.0, "fat_g": 11.0, "fiber_g": 2.0,
        "sugar_g": 1.5, "sodium_mg": 540, "cholesterol_mg": 35, "potassium_mg": 230,
        "vitamins": "Iron, Niacin", "health_score": 7.4, "diet_type": "Non-Vegetarian",
        "health_tags": ["Japanese Dumpling", "Crispy Bottom"], "allergens": ["Gluten", "Soy", "Sesame"],
        "description": "Japanese pan-fried potstickers with crispy bottom filled with seasoned minced pork and cabbage."
    },
    "hamburger": {
        "name": "Hamburger", "category": "Fast Food", "serving_size_g": 240,
        "calories": 540, "protein_g": 30.0, "carbs_g": 42.0, "fat_g": 28.0, "fiber_g": 2.5,
        "sugar_g": 7.0, "sodium_mg": 860, "cholesterol_mg": 90, "potassium_mg": 460,
        "vitamins": "Iron, Zinc, Vitamin B12", "health_score": 5.9, "diet_type": "Non-Vegetarian",
        "health_tags": ["High Protein", "All-American Classic"], "allergens": ["Gluten", "Dairy", "Sesame"],
        "description": "Juicy grilled beef patty served in a toasted sesame bun with lettuce, tomato, pickles, and cheddar."
    },
    "hot_and_sour_soup": {
        "name": "Hot and Sour Soup", "category": "Soup", "serving_size_g": 240,
        "calories": 140, "protein_g": 8.0, "carbs_g": 14.0, "fat_g": 5.5, "fiber_g": 2.0,
        "sugar_g": 3.0, "sodium_mg": 820, "cholesterol_mg": 45, "potassium_mg": 290,
        "vitamins": "Iron, Vitamin C", "health_score": 7.8, "diet_type": "Non-Vegetarian",
        "health_tags": ["Low Calorie", "Spicy & Tangy"], "allergens": ["Soy", "Eggs", "Sesame"],
        "description": "Traditional Chinese soup with tofu, wood ear mushrooms, bamboo shoots, and egg ribbons in spicy vinegar broth."
    },
    "hot_dog": {
        "name": "Hot Dog", "category": "Fast Food", "serving_size_g": 150,
        "calories": 390, "protein_g": 14.0, "carbs_g": 32.0, "fat_g": 23.0, "fiber_g": 1.5,
        "sugar_g": 5.0, "sodium_mg": 960, "cholesterol_mg": 55, "potassium_mg": 240,
        "vitamins": "Iron, Sodium", "health_score": 4.6, "diet_type": "Non-Vegetarian",
        "health_tags": ["Fast Food", "Savory"], "allergens": ["Gluten", "Mustard"],
        "description": "Grilled frankfurter sausage served in a warm sliced bun with yellow mustard, ketchup, and relish."
    },
    "huevos_rancheros": {
        "name": "Huevos Rancheros", "category": "Breakfast", "serving_size_g": 260,
        "calories": 440, "protein_g": 22.0, "carbs_g": 38.0, "fat_g": 22.0, "fiber_g": 6.5,
        "sugar_g": 4.0, "sodium_mg": 780, "cholesterol_mg": 380, "potassium_mg": 540,
        "vitamins": "Vitamin A, Iron, Fiber", "health_score": 7.7, "diet_type": "Vegetarian",
        "health_tags": ["High Protein", "High Fiber", "Mexican Breakfast"], "allergens": ["Eggs", "Dairy"],
        "description": "Fried corn tortillas topped with fried eggs, warm spiced ranchero salsa, refried black beans, and cotija."
    },
    "hummus": {
        "name": "Hummus", "category": "Appetizer", "serving_size_g": 120,
        "calories": 210, "protein_g": 8.0, "carbs_g": 18.0, "fat_g": 13.0, "fiber_g": 6.0,
        "sugar_g": 1.0, "sodium_mg": 340, "cholesterol_mg": 0, "potassium_mg": 320,
        "vitamins": "Iron, Folate, Vitamin B6", "health_score": 9.2, "diet_type": "Vegan",
        "health_tags": ["Plant Protein", "Superfood", "Heart Healthy", "High Fiber"], "allergens": ["Sesame"],
        "description": "Creamy blend of mashed chickpeas, tahini sesame paste, lemon juice, garlic, and cold pressed olive oil."
    },
    "ice_cream": {
        "name": "Ice Cream", "category": "Dessert", "serving_size_g": 120,
        "calories": 270, "protein_g": 4.5, "carbs_g": 32.0, "fat_g": 14.5, "fiber_g": 0.5,
        "sugar_g": 28.0, "sodium_mg": 110, "cholesterol_mg": 55, "potassium_mg": 180,
        "vitamins": "Calcium, Vitamin A", "health_score": 4.3, "diet_type": "Vegetarian",
        "health_tags": ["Cold Treat", "Sweet"], "allergens": ["Dairy"],
        "description": "Rich frozen dairy dessert churned with cream, milk, vanilla bean extract, and sugar."
    },
    "lasagna": {
        "name": "Lasagna", "category": "Main Course", "serving_size_g": 300,
        "calories": 520, "protein_g": 32.0, "carbs_g": 46.0, "fat_g": 24.0, "fiber_g": 3.8,
        "sugar_g": 7.5, "sodium_mg": 920, "cholesterol_mg": 85, "potassium_mg": 560,
        "vitamins": "Calcium, Lycopene, Iron", "health_score": 6.7, "diet_type": "Non-Vegetarian",
        "health_tags": ["High Protein", "Comfort Food"], "allergens": ["Gluten", "Dairy", "Eggs"],
        "description": "Baked pasta casserole with stacked layers of lasagna sheets, bolognese meat sauce, ricotta, and mozzarella."
    },
    "lobster_bisque": {
        "name": "Lobster Bisque", "category": "Soup", "serving_size_g": 240,
        "calories": 310, "protein_g": 14.0, "carbs_g": 16.0, "fat_g": 21.0, "fiber_g": 0.8,
        "sugar_g": 4.0, "sodium_mg": 890, "cholesterol_mg": 85, "potassium_mg": 360,
        "vitamins": "Selenium, Zinc, Vitamin B12", "health_score": 6.8, "diet_type": "Pescatarian",
        "health_tags": ["Creamy Soup", "Gourmet Seafood"], "allergens": ["Shellfish", "Dairy", "Gluten"],
        "description": "Velvety smooth French soup prepared from roasted lobster stock, dry sherry, mirepoix, and heavy cream."
    },
    "lobster_roll_sandwich": {
        "name": "Lobster Roll", "category": "Main Course", "serving_size_g": 220,
        "calories": 480, "protein_g": 28.0, "carbs_g": 36.0, "fat_g": 24.0, "fiber_g": 1.5,
        "sugar_g": 3.0, "sodium_mg": 860, "cholesterol_mg": 135, "potassium_mg": 380,
        "vitamins": "Zinc, Vitamin B12, Phosphorus", "health_score": 7.0, "diet_type": "Pescatarian",
        "health_tags": ["High Protein", "New England Classic"], "allergens": ["Shellfish", "Gluten", "Dairy"],
        "description": "Chilled Maine lobster claw and tail meat lightly tossed in mayonnaise and piled high in buttered split-top roll."
    },
    "macaroni_and_cheese": {
        "name": "Macaroni and Cheese", "category": "Main Course", "serving_size_g": 220,
        "calories": 450, "protein_g": 18.0, "carbs_g": 46.0, "fat_g": 22.0, "fiber_g": 2.0,
        "sugar_g": 5.0, "sodium_mg": 810, "cholesterol_mg": 65, "potassium_mg": 210,
        "vitamins": "Calcium, Phosphorus", "health_score": 5.3, "diet_type": "Vegetarian",
        "health_tags": ["Comfort Food", "Cheesy"], "allergens": ["Gluten", "Dairy"],
        "description": "Elbow macaroni enveloped in creamy sharp cheddar cheese sauce and baked with golden breadcrumbs."
    },
    "macarons": {
        "name": "Macarons", "category": "Dessert", "serving_size_g": 60,
        "calories": 250, "protein_g": 4.5, "carbs_g": 36.0, "fat_g": 10.0, "fiber_g": 1.5,
        "sugar_g": 32.0, "sodium_mg": 65, "cholesterol_mg": 15, "potassium_mg": 95,
        "vitamins": "Vitamin E, Calcium", "health_score": 4.1, "diet_type": "Vegetarian",
        "health_tags": ["French Confection", "Sweet"], "allergens": ["Tree Nuts", "Dairy", "Eggs"],
        "description": "Delicate Parisian meringue sandwich cookies made with almond flour and filled with flavored ganache."
    },
    "miso_soup": {
        "name": "Miso Soup", "category": "Soup", "serving_size_g": 200,
        "calories": 70, "protein_g": 5.0, "carbs_g": 7.0, "fat_g": 2.5, "fiber_g": 1.5,
        "sugar_g": 2.0, "sodium_mg": 620, "cholesterol_mg": 0, "potassium_mg": 210,
        "vitamins": "Manganese, Vitamin K, Probiotics", "health_score": 8.7, "diet_type": "Pescatarian",
        "health_tags": ["Low Calorie", "Probiotic Rich", "Japanese Staple"], "allergens": ["Soy", "Fish"],
        "description": "Traditional Japanese broth made with fermented soybean miso paste, dashi stock, silken tofu, and wakame seaweed."
    },
    "mussels": {
        "name": "Mussels", "category": "Main Course", "serving_size_g": 220,
        "calories": 220, "protein_g": 26.0, "carbs_g": 8.0, "fat_g": 7.5, "fiber_g": 0.0,
        "sugar_g": 1.0, "sodium_mg": 580, "cholesterol_mg": 80, "potassium_mg": 460,
        "vitamins": "Iron, Vitamin B12, Manganese, Selenium", "health_score": 9.3, "diet_type": "Pescatarian",
        "health_tags": ["Superfood", "High Protein", "Low Calorie", "Iron Rich"], "allergens": ["Mollusks"],
        "description": "Fresh black mussels steamed in white wine, garlic butter, shallots, and fresh chopped parsley."
    },
    "nachos": {
        "name": "Nachos", "category": "Appetizer", "serving_size_g": 200,
        "calories": 560, "protein_g": 16.0, "carbs_g": 52.0, "fat_g": 32.0, "fiber_g": 5.5,
        "sugar_g": 3.0, "sodium_mg": 890, "cholesterol_mg": 45, "potassium_mg": 380,
        "vitamins": "Calcium, Vitamin A", "health_score": 5.2, "diet_type": "Vegetarian",
        "health_tags": ["Sharing Platter", "Cheesy & Crunchy"], "allergens": ["Dairy"],
        "description": "Crispy tortilla chips piled high with melted queso, black beans, jalapenos, salsa, and guacamole."
    },
    "omelette": {
        "name": "Omelette", "category": "Breakfast", "serving_size_g": 180,
        "calories": 290, "protein_g": 20.0, "carbs_g": 3.0, "fat_g": 22.0, "fiber_g": 0.8,
        "sugar_g": 1.5, "sodium_mg": 480, "cholesterol_mg": 420, "potassium_mg": 280,
        "vitamins": "Choline, Vitamin A, Vitamin D, Iron", "health_score": 8.0, "diet_type": "Vegetarian",
        "health_tags": ["High Protein", "Low Carb", "Keto"], "allergens": ["Eggs", "Dairy"],
        "description": "Whisked eggs folded gently with diced bell peppers, sautéed mushrooms, herbs, and melted cheddar."
    },
    "onion_rings": {
        "name": "Onion Rings", "category": "Fast Food", "serving_size_g": 130,
        "calories": 380, "protein_g": 4.5, "carbs_g": 44.0, "fat_g": 21.0, "fiber_g": 2.8,
        "sugar_g": 5.0, "sodium_mg": 490, "cholesterol_mg": 5, "potassium_mg": 210,
        "vitamins": "Vitamin C, Iron", "health_score": 4.8, "diet_type": "Vegetarian",
        "health_tags": ["Crispy", "Snack"], "allergens": ["Gluten"],
        "description": "Cross-sectional rings of sweet Spanish onions coated in seasoned batter and deep fried to crisp golden perfection."
    },
    "oysters": {
        "name": "Oysters", "category": "Appetizer", "serving_size_g": 150,
        "calories": 110, "protein_g": 14.0, "carbs_g": 6.0, "fat_g": 3.0, "fiber_g": 0.0,
        "sugar_g": 0.5, "sodium_mg": 380, "cholesterol_mg": 65, "potassium_mg": 290,
        "vitamins": "Zinc, Vitamin B12, Copper, Iron", "health_score": 9.7, "diet_type": "Pescatarian",
        "health_tags": ["Zinc Powerhouse", "Low Calorie", "High Protein", "Superfood"], "allergens": ["Mollusks"],
        "description": "Freshly shucked raw oysters on half shell served chilled over crushed ice with mignonette sauce and lemon."
    },
    "pad_thai": {
        "name": "Pad Thai", "category": "Main Course", "serving_size_g": 300,
        "calories": 540, "protein_g": 24.0, "carbs_g": 72.0, "fat_g": 18.0, "fiber_g": 4.0,
        "sugar_g": 12.0, "sodium_mg": 860, "cholesterol_mg": 110, "potassium_mg": 390,
        "vitamins": "Vitamin C, Iron, Calcium", "health_score": 7.3, "diet_type": "Pescatarian",
        "health_tags": ["Thai Classic", "Sweet & Tangy"], "allergens": ["Peanuts", "Eggs", "Fish", "Soy"],
        "description": "Stir-fried rice noodles tossed with tamarind sauce, shrimp, tofu, bean sprouts, scrambled egg, and crushed peanuts."
    },
    "paella": {
        "name": "Paella", "category": "Main Course", "serving_size_g": 320,
        "calories": 510, "protein_g": 28.0, "carbs_g": 66.0, "fat_g": 15.0, "fiber_g": 3.5,
        "sugar_g": 3.0, "sodium_mg": 740, "cholesterol_mg": 95, "potassium_mg": 460,
        "vitamins": "Iron, Vitamin C, Saffron", "health_score": 7.8, "diet_type": "Non-Vegetarian",
        "health_tags": ["Spanish Classic", "Seafood & Rice"], "allergens": ["Shellfish", "Fish"],
        "description": "Valencian saffron-infused rice pan-cooked with shrimp, mussels, calamari, chicken, and green beans."
    },
    "pancakes": {
        "name": "Pancakes", "category": "Breakfast", "serving_size_g": 180,
        "calories": 380, "protein_g": 8.0, "carbs_g": 58.0, "fat_g": 12.5, "fiber_g": 2.0,
        "sugar_g": 16.0, "sodium_mg": 520, "cholesterol_mg": 55, "potassium_mg": 210,
        "vitamins": "Calcium, Iron", "health_score": 5.6, "diet_type": "Vegetarian",
        "health_tags": ["Fluffy", "Breakfast Staple"], "allergens": ["Gluten", "Dairy", "Eggs"],
        "description": "Golden fluffy buttermilk hotcakes stacked and topped with whipped butter and pure maple syrup."
    },
    "panna_cotta": {
        "name": "Panna Cotta", "category": "Dessert", "serving_size_g": 130,
        "calories": 290, "protein_g": 4.5, "carbs_g": 26.0, "fat_g": 19.0, "fiber_g": 0.5,
        "sugar_g": 22.0, "sodium_mg": 70, "cholesterol_mg": 65, "potassium_mg": 130,
        "vitamins": "Calcium, Vitamin A", "health_score": 4.7, "diet_type": "Vegetarian",
        "health_tags": ["Silky", "Italian Dessert"], "allergens": ["Dairy"],
        "description": "Silky chilled Italian dessert of sweetened cream thickened with gelatin and topped with berry coulis."
    },
    "peking_duck": {
        "name": "Peking Duck", "category": "Main Course", "serving_size_g": 240,
        "calories": 580, "protein_g": 34.0, "carbs_g": 22.0, "fat_g": 40.0, "fiber_g": 1.5,
        "sugar_g": 6.0, "sodium_mg": 780, "cholesterol_mg": 130, "potassium_mg": 420,
        "vitamins": "Iron, Niacin, Vitamin B6", "health_score": 6.5, "diet_type": "Non-Vegetarian",
        "health_tags": ["Crispy Skin", "Imperial Delicacy"], "allergens": ["Gluten", "Soy", "Sesame"],
        "description": "Famed Beijing roasted duck characterized by crackling crisp skin, served with thin pancakes, scallions, and hoisin sauce."
    },
    "pho": {
        "name": "Pho", "category": "Soup", "serving_size_g": 400,
        "calories": 390, "protein_g": 26.0, "carbs_g": 52.0, "fat_g": 8.0, "fiber_g": 3.0,
        "sugar_g": 4.0, "sodium_mg": 920, "cholesterol_mg": 55, "potassium_mg": 510,
        "vitamins": "Iron, Vitamin C, Star Anise / Herbs", "health_score": 8.5, "diet_type": "Non-Vegetarian",
        "health_tags": ["Aromatic Broth", "Comfort Food", "Gluten Free Friendly"], "allergens": ["Fish"],
        "description": "Vietnamese aromatic beef bone broth with flat rice noodles, thinly sliced brisket, basil, cilantro, and bean sprouts."
    },
    "pizza": {
        "name": "Pizza", "category": "Main Course", "serving_size_g": 200,
        "calories": 480, "protein_g": 22.0, "carbs_g": 54.0, "fat_g": 20.0, "fiber_g": 3.2,
        "sugar_g": 5.0, "sodium_mg": 860, "cholesterol_mg": 45, "potassium_mg": 320,
        "vitamins": "Calcium, Lycopene, Iron", "health_score": 6.2, "diet_type": "Vegetarian",
        "health_tags": ["Classic Favorite", "Cheesy"], "allergens": ["Gluten", "Dairy"],
        "description": "Oven-baked flatbread topped with spiced tomato marinara, mozzarella cheese, and fresh oregano."
    },
    "pork_chop": {
        "name": "Pork Chop", "category": "Main Course", "serving_size_g": 220,
        "calories": 420, "protein_g": 44.0, "carbs_g": 0.0, "fat_g": 26.0, "fiber_g": 0.0,
        "sugar_g": 0.0, "sodium_mg": 310, "cholesterol_mg": 130, "potassium_mg": 620,
        "vitamins": "Thiamine (B1), Niacin, Zinc", "health_score": 7.6, "diet_type": "Non-Vegetarian",
        "health_tags": ["High Protein", "Zero Carb", "Keto"], "allergens": ["None"],
        "description": "Thick center-cut bone-in pork chop pan-seared and finished with rosemary garlic butter."
    },
    "poutine": {
        "name": "Poutine", "category": "Fast Food", "serving_size_g": 250,
        "calories": 620, "protein_g": 18.0, "carbs_g": 64.0, "fat_g": 34.0, "fiber_g": 5.0,
        "sugar_g": 2.0, "sodium_mg": 1050, "cholesterol_mg": 60, "potassium_mg": 680,
        "vitamins": "Potassium, Calcium", "health_score": 4.5, "diet_type": "Non-Vegetarian",
        "health_tags": ["Canadian Classic", "Hearty Indulgence"], "allergens": ["Dairy", "Gluten"],
        "description": "Crispy French fries smothered with squeaky cheese curds and piping hot savory brown beef gravy."
    },
    "prime_rib": {
        "name": "Prime Rib", "category": "Main Course", "serving_size_g": 260,
        "calories": 610, "protein_g": 48.0, "carbs_g": 0.0, "fat_g": 45.0, "fiber_g": 0.0,
        "sugar_g": 0.0, "sodium_mg": 380, "cholesterol_mg": 175, "potassium_mg": 590,
        "vitamins": "Iron, Vitamin B12, Zinc", "health_score": 6.8, "diet_type": "Non-Vegetarian",
        "health_tags": ["High Protein", "Carnivore Friendly", "Keto"], "allergens": ["None"],
        "description": "Slow-roasted bone-in ribeye roast cooked medium-rare and carved with au jus."
    },
    "pulled_pork_sandwich": {
        "name": "Pulled Pork Sandwich", "category": "Main Course", "serving_size_g": 260,
        "calories": 560, "protein_g": 36.0, "carbs_g": 46.0, "fat_g": 25.0, "fiber_g": 2.5,
        "sugar_g": 14.0, "sodium_mg": 980, "cholesterol_mg": 115, "potassium_mg": 480,
        "vitamins": "Thiamine, Iron, Vitamin B6", "health_score": 6.1, "diet_type": "Non-Vegetarian",
        "health_tags": ["High Protein", "Smoky BBQ"], "allergens": ["Gluten"],
        "description": "Slow-smoked tender shredded pork shoulder tossed in tangy BBQ sauce and piled onto toasted brioche bun."
    },
    "ramen": {
        "name": "Ramen", "category": "Soup", "serving_size_g": 420,
        "calories": 520, "protein_g": 26.0, "carbs_g": 64.0, "fat_g": 18.0, "fiber_g": 3.5,
        "sugar_g": 3.5, "sodium_mg": 1280, "cholesterol_mg": 95, "potassium_mg": 440,
        "vitamins": "Iron, Niacin, Choline", "health_score": 6.7, "diet_type": "Non-Vegetarian",
        "health_tags": ["Comfort Food", "Rich Umami Broth"], "allergens": ["Gluten", "Eggs", "Soy", "Sesame"],
        "description": "Japanese wheat noodles in creamy tonkotsu bone broth topped with chashu pork belly, ajitsuke tamago egg, and nori."
    },
    "ravioli": {
        "name": "Ravioli", "category": "Main Course", "serving_size_g": 220,
        "calories": 380, "protein_g": 18.0, "carbs_g": 48.0, "fat_g": 14.0, "fiber_g": 3.0,
        "sugar_g": 4.5, "sodium_mg": 680, "cholesterol_mg": 65, "potassium_mg": 310,
        "vitamins": "Calcium, Iron", "health_score": 7.1, "diet_type": "Vegetarian",
        "health_tags": ["Italian Classic", "Ricotta Stuffed"], "allergens": ["Gluten", "Dairy", "Eggs"],
        "description": "Handmade pasta pillows filled with seasoned ricotta cheese and spinach, coated in marinara sauce."
    },
    "red_velvet_cake": {
        "name": "Red Velvet Cake", "category": "Dessert", "serving_size_g": 125,
        "calories": 430, "protein_g": 5.0, "carbs_g": 56.0, "fat_g": 21.0, "fiber_g": 1.2,
        "sugar_g": 39.0, "sodium_mg": 340, "cholesterol_mg": 55, "potassium_mg": 160,
        "vitamins": "Calcium, Iron", "health_score": 4.1, "diet_type": "Vegetarian",
        "health_tags": ["Sweet", "Celebration Cake"], "allergens": ["Gluten", "Dairy", "Eggs"],
        "description": "Crimson cocoa sponge cake with subtle buttermilk tang frosted with signature cream cheese icing."
    },
    "risotto": {
        "name": "Risotto", "category": "Main Course", "serving_size_g": 240,
        "calories": 380, "protein_g": 9.0, "carbs_g": 54.0, "fat_g": 14.0, "fiber_g": 2.0,
        "sugar_g": 2.5, "sodium_mg": 620, "cholesterol_mg": 35, "potassium_mg": 210,
        "vitamins": "Calcium, Iron", "health_score": 7.0, "diet_type": "Vegetarian",
        "health_tags": ["Creamy Rice", "Italian Gourmet"], "allergens": ["Dairy"],
        "description": "Slow-cooked Arborio rice coaxed into creamy texture with white wine, chicken or vegetable broth, butter, and Parmesan."
    },
    "samosa": {
        "name": "Samosa", "category": "Appetizer", "serving_size_g": 120,
        "calories": 280, "protein_g": 6.0, "carbs_g": 34.0, "fat_g": 14.0, "fiber_g": 3.8,
        "sugar_g": 2.0, "sodium_mg": 460, "cholesterol_mg": 5, "potassium_mg": 320,
        "vitamins": "Potassium, Vitamin C, Iron", "health_score": 6.6, "diet_type": "Vegetarian",
        "health_tags": ["Spiced", "Crispy Indian Snack"], "allergens": ["Gluten"],
        "description": "Crisp fried triangular pastry stuffed with spiced potato mash, green peas, cumin, coriander, and garam masala."
    },
    "sashimi": {
        "name": "Sashimi", "category": "Appetizer", "serving_size_g": 140,
        "calories": 180, "protein_g": 32.0, "carbs_g": 0.0, "fat_g": 6.0, "fiber_g": 0.0,
        "sugar_g": 0.0, "sodium_mg": 110, "cholesterol_mg": 65, "potassium_mg": 540,
        "vitamins": "Omega-3, Vitamin D, Vitamin B12, Selenium", "health_score": 9.9, "diet_type": "Pescatarian",
        "health_tags": ["Pure Protein", "Superfood", "Zero Carb", "Heart Healthy"], "allergens": ["Fish"],
        "description": "Pristine slices of raw sashimi-grade salmon, tuna, and yellowtail served with wasabi and soy sauce."
    },
    "scallops": {
        "name": "Scallops", "category": "Main Course", "serving_size_g": 160,
        "calories": 190, "protein_g": 28.0, "carbs_g": 5.0, "fat_g": 6.5, "fiber_g": 0.0,
        "sugar_g": 1.0, "sodium_mg": 390, "cholesterol_mg": 60, "potassium_mg": 480,
        "vitamins": "Vitamin B12, Magnesium, Potassium", "health_score": 9.4, "diet_type": "Pescatarian",
        "health_tags": ["High Protein", "Low Calorie", "Delicate Seafood"], "allergens": ["Mollusks"],
        "description": "Jumbo sea scallops pan-seared to caramelized golden crust and basted with garlic lemon herb butter."
    },
    "seaweed_salad": {
        "name": "Seaweed Salad", "category": "Salad", "serving_size_g": 120,
        "calories": 95, "protein_g": 2.5, "carbs_g": 12.0, "fat_g": 4.5, "fiber_g": 3.0,
        "sugar_g": 4.0, "sodium_mg": 480, "cholesterol_mg": 0, "potassium_mg": 280,
        "vitamins": "Iodine, Vitamin K, Iron, Folate", "health_score": 9.3, "diet_type": "Vegan",
        "health_tags": ["Mineral Rich", "Low Calorie", "Thyroid Health"], "allergens": ["Sesame", "Soy"],
        "description": "Wakame seaweed ribbons tossed with roasted sesame oil, rice vinegar, soy sauce, and toasted sesame seeds."
    },
    "shrimp_and_grits": {
        "name": "Shrimp and Grits", "category": "Main Course", "serving_size_g": 280,
        "calories": 480, "protein_g": 32.0, "carbs_g": 42.0, "fat_g": 21.0, "fiber_g": 2.5,
        "sugar_g": 2.5, "sodium_mg": 890, "cholesterol_mg": 185, "potassium_mg": 420,
        "vitamins": "Zinc, Vitamin B12, Iron", "health_score": 7.2, "diet_type": "Pescatarian",
        "health_tags": ["High Protein", "Southern Comfort"], "allergens": ["Shellfish", "Dairy"],
        "description": "Plump sautéed Gulf shrimp and andouille sausage served over rich cheddar stone-ground corn grits."
    },
    "spaghetti_bolognese": {
        "name": "Spaghetti Bolognese", "category": "Main Course", "serving_size_g": 320,
        "calories": 520, "protein_g": 28.0, "carbs_g": 62.0, "fat_g": 18.0, "fiber_g": 4.5,
        "sugar_g": 6.5, "sodium_mg": 740, "cholesterol_mg": 65, "potassium_mg": 580,
        "vitamins": "Lycopene, Iron, B Vitamins", "health_score": 7.4, "diet_type": "Non-Vegetarian",
        "health_tags": ["High Protein", "Italian Classic", "Energy Dense"], "allergens": ["Gluten", "Dairy"],
        "description": "Spaghetti tossed with slow-simmered bolognese sauce of minced beef, tomato, wine, and aromatic vegetables."
    },
    "spaghetti_carbonara": {
        "name": "Spaghetti Carbonara", "category": "Main Course", "serving_size_g": 280,
        "calories": 580, "protein_g": 26.0, "carbs_g": 54.0, "fat_g": 28.0, "fiber_g": 2.5,
        "sugar_g": 2.5, "sodium_mg": 890, "cholesterol_mg": 195, "potassium_mg": 310,
        "vitamins": "Calcium, Vitamin B12, Iron", "health_score": 6.2, "diet_type": "Non-Vegetarian",
        "health_tags": ["Roman Classic", "Creamy Egg & Cheese"], "allergens": ["Gluten", "Dairy", "Eggs"],
        "description": "Spaghetti coated in rich sauce of beaten eggs, pecorino romano, guanciale cured pork, and black pepper."
    },
    "spring_rolls": {
        "name": "Spring Rolls", "category": "Appetizer", "serving_size_g": 130,
        "calories": 240, "protein_g": 6.0, "carbs_g": 28.0, "fat_g": 12.0, "fiber_g": 2.5,
        "sugar_g": 3.0, "sodium_mg": 460, "cholesterol_mg": 15, "potassium_mg": 190,
        "vitamins": "Vitamin A, Vitamin C", "health_score": 6.9, "diet_type": "Vegetarian",
        "health_tags": ["Crispy", "Asian Appetizer"], "allergens": ["Gluten", "Soy"],
        "description": "Crispy golden fried thin pastry filled with shredded cabbage, carrots, glass noodles, and mushrooms."
    },
    "steak": {
        "name": "Steak (Ribeye / Sirloin)", "category": "Main Course", "serving_size_g": 240,
        "calories": 560, "protein_g": 52.0, "carbs_g": 0.0, "fat_g": 38.0, "fiber_g": 0.0,
        "sugar_g": 0.0, "sodium_mg": 290, "cholesterol_mg": 160, "potassium_mg": 680,
        "vitamins": "Iron, Zinc, Vitamin B12", "health_score": 8.0, "diet_type": "Non-Vegetarian",
        "health_tags": ["High Protein", "Zero Carb", "Keto"], "allergens": ["None"],
        "description": "Thick-cut grilled beef steak seasoned with kosher salt, cracked pepper, and garlic thyme butter."
    },
    "strawberry_shortcake": {
        "name": "Strawberry Shortcake", "category": "Dessert", "serving_size_g": 140,
        "calories": 340, "protein_g": 4.5, "carbs_g": 46.0, "fat_g": 16.0, "fiber_g": 2.4,
        "sugar_g": 26.0, "sodium_mg": 280, "cholesterol_mg": 45, "potassium_mg": 180,
        "vitamins": "Vitamin C, Calcium", "health_score": 5.4, "diet_type": "Vegetarian",
        "health_tags": ["Fresh Berries", "Sweet"], "allergens": ["Gluten", "Dairy", "Eggs"],
        "description": "Tender biscuit cake layered with macerated fresh strawberries and heaps of Chantilly whipped cream."
    },
    "sushi": {
        "name": "Sushi / Nigiri / Maki", "category": "Main Course", "serving_size_g": 200,
        "calories": 310, "protein_g": 16.0, "carbs_g": 52.0, "fat_g": 4.5, "fiber_g": 2.5,
        "sugar_g": 6.0, "sodium_mg": 580, "cholesterol_mg": 40, "potassium_mg": 310,
        "vitamins": "Iodine, Omega-3, Vitamin B12", "health_score": 8.6, "diet_type": "Pescatarian",
        "health_tags": ["Clean Eating", "Low Fat", "Omega 3"], "allergens": ["Fish", "Soy"],
        "description": "Vinegared seasoned sushi rice roll filled with fresh salmon, avocado, cucumber, and wrapped in toasted nori."
    },
    "tacos": {
        "name": "Tacos", "category": "Main Course", "serving_size_g": 190,
        "calories": 420, "protein_g": 24.0, "carbs_g": 32.0, "fat_g": 22.0, "fiber_g": 4.5,
        "sugar_g": 2.5, "sodium_mg": 680, "cholesterol_mg": 65, "potassium_mg": 410,
        "vitamins": "Vitamin C, Iron, Calcium", "health_score": 7.5, "diet_type": "Non-Vegetarian",
        "health_tags": ["High Protein", "Mexican Street Food"], "allergens": ["Dairy"],
        "description": "Soft or crisp corn tortillas filled with spiced carne asada or chicken, cilantro, diced white onion, and salsa."
    },
    "takoyaki": {
        "name": "Takoyaki", "category": "Appetizer", "serving_size_g": 160,
        "calories": 290, "protein_g": 13.0, "carbs_g": 34.0, "fat_g": 11.5, "fiber_g": 1.5,
        "sugar_g": 4.0, "sodium_mg": 620, "cholesterol_mg": 85, "potassium_mg": 240,
        "vitamins": "Iron, Vitamin B12", "health_score": 6.9, "diet_type": "Pescatarian",
        "health_tags": ["Japanese Street Food", "Savory"], "allergens": ["Mollusks", "Gluten", "Eggs", "Soy"],
        "description": "Ball-shaped Japanese savory batter balls filled with minced octopus pieces, brushed with takoyaki sauce and bonito flakes."
    },
    "tiramisu": {
        "name": "Tiramisu", "category": "Dessert", "serving_size_g": 130,
        "calories": 380, "protein_g": 6.0, "carbs_g": 36.0, "fat_g": 24.0, "fiber_g": 1.0,
        "sugar_g": 24.0, "sodium_mg": 120, "cholesterol_mg": 130, "potassium_mg": 150,
        "vitamins": "Calcium, Vitamin A", "health_score": 4.4, "diet_type": "Vegetarian",
        "health_tags": ["Coffee Infused", "Italian Classic"], "allergens": ["Gluten", "Dairy", "Eggs"],
        "description": "Coffee-flavored Italian dessert featuring ladyfingers dipped in espresso, layered with whipped mascarpone and cocoa."
    },
    "tuna_tartare": {
        "name": "Tuna Tartare", "category": "Appetizer", "serving_size_g": 140,
        "calories": 210, "protein_g": 28.0, "carbs_g": 4.0, "fat_g": 9.0, "fiber_g": 2.2,
        "sugar_g": 1.0, "sodium_mg": 380, "cholesterol_mg": 55, "potassium_mg": 510,
        "vitamins": "Omega-3, Vitamin D, Selenium, B12", "health_score": 9.6, "diet_type": "Pescatarian",
        "health_tags": ["Superfood", "High Protein", "Omega 3", "Heart Healthy"], "allergens": ["Fish", "Soy", "Sesame"],
        "description": "Diced raw sushi-grade yellowfin tuna tossed with toasted sesame oil, ginger, lime, and creamy diced avocado."
    },
    "waffles": {
        "name": "Waffles", "category": "Breakfast", "serving_size_g": 140,
        "calories": 350, "protein_g": 8.0, "carbs_g": 44.0, "fat_g": 16.0, "fiber_g": 1.8,
        "sugar_g": 14.0, "sodium_mg": 460, "cholesterol_mg": 60, "potassium_mg": 180,
        "vitamins": "Calcium, Iron", "health_score": 5.2, "diet_type": "Vegetarian",
        "health_tags": ["Crisp Grid", "Brunch Staple"], "allergens": ["Gluten", "Dairy", "Eggs"],
        "description": "Belgian waffle with deep pockets, crispy golden exterior, served warm with berries and maple syrup."
    }
}

def main():
    os.makedirs("data", exist_ok=True)
    
    # Save classes list
    with open("data/food101_classes.json", "w", encoding="utf-8") as f:
        json.dump(CLASSES_101, f, indent=2)
    
    # Verify all classes exist in nutrition profiles
    missing = [c for c in CLASSES_101 if c not in NUTRITION_PROFILES]
    if missing:
        print(f"Warning: Missing nutrition data for {len(missing)} classes: {missing}")
    else:
        print(f"Success: All {len(CLASSES_101)} Food-101 classes have complete nutritional profiles!")
        
    with open("data/food101_nutrition.json", "w", encoding="utf-8") as f:
        json.dump(NUTRITION_PROFILES, f, indent=2)
        
    print(f"Generated data/food101_classes.json with {len(CLASSES_101)} classes.")
    print(f"Generated data/food101_nutrition.json with {len(NUTRITION_PROFILES)} items.")

if __name__ == "__main__":
    main()
