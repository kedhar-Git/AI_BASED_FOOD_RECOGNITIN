"""
Food-101 Dataset Loader for PyTorch (Kaggle dataset: dansbecker/food-101)
Supports:
- Kaggle Food-101 folder layout (images/ + meta/)
- Standard torchvision ImageFolder format
- Data augmentations (RandomResizedCrop, Flip, Rotation, ColorJitter)
- Train/Validation/Test split creation
"""

import os
import json
from typing import Tuple, Optional, Callable
from PIL import Image
import torch
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms

# ImageNet / Food-101 Normalization Constants
IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]

def get_food101_transforms(img_size: int = 224):
    """Returns training and validation transform pipelines."""
    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(img_size, scale=(0.8, 1.0)),
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.RandomRotation(degrees=15),
        transforms.ColorJitter(brightness=0.15, contrast=0.15, saturation=0.15),
        transforms.ToTensor(),
        transforms.Normalize(mean=IMAGENET_MEAN, std=IMAGENET_STD)
    ])
    
    val_transform = transforms.Compose([
        transforms.Resize(int(img_size * 1.14)),
        transforms.CenterCrop(img_size),
        transforms.ToTensor(),
        transforms.Normalize(mean=IMAGENET_MEAN, std=IMAGENET_STD)
    ])
    
    return train_transform, val_transform

class Food101Dataset(Dataset):
    """
    Dataset handler for Food-101 (dansbecker/food-101).
    Reads either split files (meta/train.txt, meta/test.txt) or subdirectories.
    """
    def __init__(
        self,
        root_dir: str,
        split: str = "train",
        transform: Optional[Callable] = None,
        classes_path: Optional[str] = None
    ):
        self.root_dir = root_dir
        self.split = split
        self.transform = transform
        
        # Load canonical classes
        if classes_path is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            classes_path = os.path.join(base_dir, "data", "food101_classes.json")
            
        with open(classes_path, "r", encoding="utf-8") as f:
            self.classes = json.load(f)
        self.class_to_idx = {c: i for i, c in enumerate(self.classes)}
        
        self.samples = []
        self._find_samples()

    def _find_samples(self):
        # Check if Kaggle structure exists
        images_dir = os.path.join(self.root_dir, "images")
        if not os.path.exists(images_dir):
            images_dir = self.root_dir
            
        meta_file = os.path.join(self.root_dir, "meta", f"{self.split}.txt")
        
        if os.path.exists(meta_file):
            print(f"[Dataset] Loading from split file: {meta_file}")
            with open(meta_file, "r", encoding="utf-8") as f:
                lines = [line.strip() for line in f if line.strip()]
                
            for line in lines:
                parts = line.split("/")
                class_name = parts[0]
                img_path = os.path.join(images_dir, f"{line}.jpg")
                if os.path.exists(img_path) and class_name in self.class_to_idx:
                    self.samples.append((img_path, self.class_to_idx[class_name]))
        else:
            # Fallback: traverse directories
            print(f"[Dataset] Traversing directory: {images_dir}")
            for class_name in os.listdir(images_dir):
                class_path = os.path.join(images_dir, class_name)
                if os.path.isdir(class_path) and class_name in self.class_to_idx:
                    class_idx = self.class_to_idx[class_name]
                    for fname in os.listdir(class_path):
                        if fname.lower().endswith((".jpg", ".jpeg", ".png")):
                            self.samples.append((os.path.join(class_path, fname), class_idx))

        print(f"[Dataset] Loaded {len(self.samples)} samples for split='{self.split}'.")

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, int]:
        img_path, label = self.samples[idx]
        image = Image.open(img_path).convert("RGB")
        if self.transform:
            image = self.transform(image)
        return image, label

def create_food101_dataloaders(
    data_dir: str,
    batch_size: int = 32,
    num_workers: int = 2
) -> Tuple[DataLoader, DataLoader]:
    """Factory creating Train and Validation DataLoaders."""
    train_tf, val_tf = get_food101_transforms()
    
    train_dataset = Food101Dataset(data_dir, split="train", transform=train_tf)
    val_dataset = Food101Dataset(data_dir, split="test", transform=val_tf)
    
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=torch.cuda.is_available()
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=torch.cuda.is_available()
    )
    
    return train_loader, val_loader
