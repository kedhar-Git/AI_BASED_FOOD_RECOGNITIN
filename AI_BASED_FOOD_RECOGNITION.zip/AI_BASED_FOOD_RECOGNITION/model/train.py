"""
Transfer Learning & Fine-Tuning Pipeline for Food-101
Trains EfficientNet-B0 or MobileNet-V2 on the Food-101 dataset.

Usage:
  python model/train.py --data_dir /path/to/food-101 --model efficientnet_b0 --epochs 10 --batch_size 32
"""

import os
import sys
import argparse
import time
import json
import torch
import torch.nn as nn
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR

from .architecture import FoodClassifier
from data.dataset_loader import create_food101_dataloaders

def calculate_topk_accuracy(outputs: torch.Tensor, targets: torch.Tensor, topk=(1, 5)):
    """Computes precision@k for the specified values of k."""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = targets.size(0)

        _, pred = outputs.topk(maxk, 1, True, True)
        pred = pred.t()
        correct = pred.eq(targets.view(1, -1).expand_as(pred))

        res = []
        for k in topk:
            correct_k = correct[:k].reshape(-1).float().sum(0, keepdim=True)
            res.append(correct_k.mul_(100.0 / batch_size).item())
        return res

def train_epoch(model, loader, criterion, optimizer, device):
    model.train()
    running_loss = 0.0
    running_top1 = 0.0
    running_top5 = 0.0
    total_samples = 0

    for i, (images, targets) in enumerate(loader):
        images, targets = images.to(device), targets.to(device)
        
        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, targets)
        loss.backward()
        optimizer.step()

        top1, top5 = calculate_topk_accuracy(outputs, targets, topk=(1, 5))
        batch_size = targets.size(0)
        
        running_loss += loss.item() * batch_size
        running_top1 += top1 * batch_size
        running_top5 += top5 * batch_size
        total_samples += batch_size

        if (i + 1) % 20 == 0:
            print(f"  Step [{i+1}/{len(loader)}] Loss: {loss.item():.4f} | Top-1: {top1:.2f}% | Top-5: {top5:.2f}%")

    return (
        running_loss / total_samples,
        running_top1 / total_samples,
        running_top5 / total_samples
    )

def evaluate(model, loader, criterion, device):
    model.eval()
    running_loss = 0.0
    running_top1 = 0.0
    running_top5 = 0.0
    total_samples = 0

    with torch.no_grad():
        for images, targets in loader:
            images, targets = images.to(device), targets.to(device)
            outputs = model(images)
            loss = criterion(outputs, targets)

            top1, top5 = calculate_topk_accuracy(outputs, targets, topk=(1, 5))
            batch_size = targets.size(0)
            
            running_loss += loss.item() * batch_size
            running_top1 += top1 * batch_size
            running_top5 += top5 * batch_size
            total_samples += batch_size

    return (
        running_loss / total_samples,
        running_top1 / total_samples,
        running_top5 / total_samples
    )

def main():
    parser = argparse.ArgumentParser(description="Food-101 Deep Learning Model Trainer")
    parser.add_argument("--data_dir", type=str, default="./data/food-101", help="Path to Food-101 dataset")
    parser.add_argument("--model", type=str, default="efficientnet_b0", choices=["efficientnet_b0", "mobilenet_v2", "custom_cnn"])
    parser.add_argument("--epochs", type=int, default=10, help="Total training epochs")
    parser.add_argument("--batch_size", type=int, default=32, help="DataLoader batch size")
    parser.add_argument("--lr", type=float, default=1e-4, help="Learning rate")
    parser.add_argument("--output_dir", type=str, default="./weights", help="Directory to save model checkpoints")
    parser.add_argument("--freeze_epochs", type=int, default=2, help="Epochs to train only the classification head")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"=== Starting Training on Device: {device} ===")
    print(f"Architecture: {args.model} | Epochs: {args.epochs} | Batch Size: {args.batch_size} | LR: {args.lr}")

    if not os.path.exists(args.data_dir):
        print(f"Error: Dataset directory '{args.data_dir}' not found.")
        print("Please download Food-101 dataset from Kaggle (dansbecker/food-101) or specify --data_dir.")
        return

    # Create DataLoaders
    train_loader, val_loader = create_food101_dataloaders(args.data_dir, batch_size=args.batch_size)

    # Initialize model
    is_frozen = args.freeze_epochs > 0 and args.model != "custom_cnn"
    model = FoodClassifier(
        model_type=args.model,
        num_classes=101,
        pretrained=True,
        freeze_backbone=is_frozen
    ).to(device)

    criterion = nn.CrossEntropyLoss(label_smoothing=0.1)
    optimizer = AdamW(filter(lambda p: p.requires_grad, model.parameters()), lr=args.lr, weight_decay=1e-4)
    scheduler = CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=1e-6)

    best_val_acc = 0.0
    history = {"train_loss": [], "val_loss": [], "train_top1": [], "val_top1": [], "val_top5": []}

    start_time = time.time()
    for epoch in range(1, args.epochs + 1):
        # Unfreeze backbone after warm-up
        if epoch == args.freeze_epochs + 1 and args.model != "custom_cnn":
            print("[Fine-Tuning] Unfreezing feature extractor backbone for full network fine-tuning...")
            model.unfreeze_all()
            optimizer = AdamW(model.parameters(), lr=args.lr * 0.2, weight_decay=1e-4)

        print(f"\n--- Epoch {epoch}/{args.epochs} ---")
        train_loss, train_top1, train_top5 = train_epoch(model, train_loader, criterion, optimizer, device)
        val_loss, val_top1, val_top5 = evaluate(model, val_loader, criterion, device)
        scheduler.step()

        print(f"Epoch {epoch} Summary: Train Loss={train_loss:.4f}, Train Top-1={train_top1:.2f}% | Val Loss={val_loss:.4f}, Val Top-1={val_top1:.2f}%, Val Top-5={val_top5:.2f}%")

        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss)
        history["train_top1"].append(train_top1)
        history["val_top1"].append(val_top1)
        history["val_top5"].append(val_top5)

        # Save best checkpoint
        if val_top1 > best_val_acc:
            best_val_acc = val_top1
            save_path = os.path.join(args.output_dir, f"{args.model}_best.pth")
            torch.save(model.state_dict(), save_path)
            print(f"--> Saved New Best Model ({best_val_acc:.2f}%) to {save_path}")

    total_time = time.time() - start_time
    print(f"\nTraining Completed in {total_time/60:.2f} minutes. Best Val Top-1 Acc: {best_val_acc:.2f}%")

    # Save history metrics
    history_file = os.path.join(args.output_dir, f"{args.model}_training_history.json")
    with open(history_file, "w") as f:
        json.dump(history, f, indent=2)
    print(f"Metrics saved to {history_file}")

if __name__ == "__main__":
    main()
