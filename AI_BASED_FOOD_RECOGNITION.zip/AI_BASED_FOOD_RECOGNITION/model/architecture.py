"""
Deep Learning Model Architecture for Food Recognition (Food-101 Benchmark)
Supports:
1. EfficientNet-B0 with Transfer Learning (Primary model as specified in project abstract)
2. MobileNet-V2 with Transfer Learning (Fast mobile-friendly baseline)
3. Custom FoodCNN (Multi-layer convolutional architecture for academic ablation study)
"""

import torch
import torch.nn as nn
import torchvision.models as models
from typing import Optional, Literal

class CustomFoodCNN(nn.Module):
    """
    Custom 6-layer Deep Convolutional Neural Network architecture
    useful for academic comparisons and ablation studies against Transfer Learning.
    """
    def __init__(self, num_classes: int = 101, dropout_rate: float = 0.3):
        super(CustomFoodCNN, self).__init__()
        
        self.features = nn.Sequential(
            # Block 1: 3 -> 32
            nn.Conv2d(3, 32, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2), # 112x112
            
            # Block 2: 32 -> 64
            nn.Conv2d(32, 64, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2), # 56x56
            
            # Block 3: 64 -> 128
            nn.Conv2d(64, 128, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2), # 28x28
            
            # Block 4: 128 -> 256
            nn.Conv2d(128, 256, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2), # 14x14
            
            # Block 5: 256 -> 512
            nn.Conv2d(256, 512, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d((1, 1)) # 1x1
        )
        
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Dropout(p=dropout_rate),
            nn.Linear(512, 256),
            nn.ReLU(inplace=True),
            nn.Dropout(p=dropout_rate / 2),
            nn.Linear(256, num_classes)
        )
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        feat = self.features(x)
        return self.classifier(feat)


class FoodClassifier(nn.Module):
    """
    Transfer Learning Food Classifier wrapper.
    Adapts pre-trained deep architectures (EfficientNet-B0 or MobileNet-V2) to Food-101.
    """
    def __init__(
        self,
        model_type: Literal["efficientnet_b0", "mobilenet_v2", "custom_cnn"] = "efficientnet_b0",
        num_classes: int = 101,
        pretrained: bool = True,
        freeze_backbone: bool = False
    ):
        super(FoodClassifier, self).__init__()
        self.model_type = model_type
        self.num_classes = num_classes

        if model_type == "efficientnet_b0":
            weights = models.EfficientNet_B0_Weights.DEFAULT if pretrained else None
            base_model = models.efficientnet_b0(weights=weights)
            
            if freeze_backbone:
                for param in base_model.features.parameters():
                    param.requires_grad = False
                    
            in_features = base_model.classifier[1].in_features
            base_model.classifier = nn.Sequential(
                nn.Dropout(p=0.3, inplace=True),
                nn.Linear(in_features, 512),
                nn.BatchNorm1d(512),
                nn.SiLU(inplace=True),
                nn.Dropout(p=0.2),
                nn.Linear(512, num_classes)
            )
            self.backbone = base_model
            
        elif model_type == "mobilenet_v2":
            weights = models.MobileNet_V2_Weights.DEFAULT if pretrained else None
            base_model = models.mobilenet_v2(weights=weights)
            
            if freeze_backbone:
                for param in base_model.features.parameters():
                    param.requires_grad = False
                    
            in_features = base_model.classifier[1].in_features
            base_model.classifier = nn.Sequential(
                nn.Dropout(p=0.2, inplace=True),
                nn.Linear(in_features, 512),
                nn.BatchNorm1d(512),
                nn.ReLU6(inplace=True),
                nn.Dropout(p=0.2),
                nn.Linear(512, num_classes)
            )
            self.backbone = base_model
            
        elif model_type == "custom_cnn":
            self.backbone = CustomFoodCNN(num_classes=num_classes)
        else:
            raise ValueError(f"Unsupported model type: {model_type}")

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.backbone(x)

    def unfreeze_all(self):
        """Unfreeze all layers for end-to-end fine-tuning."""
        for param in self.parameters():
            param.requires_grad = True


def build_food_model(
    model_type: str = "efficientnet_b0",
    num_classes: int = 101,
    checkpoint_path: Optional[str] = None,
    device: Optional[torch.device] = None
) -> FoodClassifier:
    """Factory helper to build and optionally restore checkpoints."""
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
    model = FoodClassifier(
        model_type=model_type,
        num_classes=num_classes,
        pretrained=True
    )
    
    if checkpoint_path and torch.os.path.exists(checkpoint_path):
        state_dict = torch.load(checkpoint_path, map_location=device)
        model.load_state_dict(state_dict)
        print(f"[Model] Loaded checkpoint from {checkpoint_path}")
        
    model.to(device)
    model.eval()
    return model
