"""
Model package for Food-101 Deep Learning Classification
"""

from .architecture import FoodClassifier, build_food_model
from .inference import FoodInferenceEngine

__all__ = ["FoodClassifier", "build_food_model", "FoodInferenceEngine"]
