import os
import sys

print("[Test] Testing imports...")
import torch
import torchvision
from PIL import Image

print(f"[Test] PyTorch Version: {torch.__version__}")
print(f"[Test] Torchvision Version: {torchvision.__version__}")

from model.architecture import build_food_model
from model.inference import FoodInferenceEngine
from nutrition.engine import NutritionEngine
from backend.database import get_today_summary, log_meal

print("[Test] Initializing Nutrition Engine...")
nut = NutritionEngine()
print(f"[Test] Loaded {len(nut.nutrition_db)} foods in database.")

print("[Test] Initializing Deep Learning Inference Engine...")
inf = FoodInferenceEngine(model_type="efficientnet_b0")
print("[Test] Model ready.")

sample = "data/sample_images/chicken_curry.jpg"
if os.path.exists(sample):
    print(f"[Test] Running prediction on {sample}...")
    res = inf.predict(sample, top_k=5)
    print(f"[Test] Predicted Food: {res['prediction']} ({res['confidence_percent']}%)")
    print(f"[Test] Top 5 Predictions: {[p['display_name'] for p in res['top_k']]}")

    lookup_res = nut.lookup(res['prediction'])
    print(f"[Test] Nutrition: {lookup_res['name']} | Calories: {lookup_res['calories']} kcal | Protein: {lookup_res['protein_g']}g")

print("[Test] Testing SQLite Database Meal Logging...")
mid = log_meal(
    food_class="chicken_curry",
    food_name="Chicken Biryani",
    serving_g=320,
    calories=480,
    protein_g=36,
    carbs_g=32,
    fat_g=22,
    fiber_g=4.2,
    sodium_mg=740,
    confidence=0.968,
    model_name="EfficientNet-B0 (Transfer Learning)",
    meal_type="Lunch"
)
print(f"[Test] Meal logged with ID: {mid}")

summary = get_today_summary()
print(f"[Test] Today Total Calories: {summary['totals']['total_calories']} kcal")

print("[Test] ALL SYSTEMS VERIFIED AND FUNCTIONAL!")
